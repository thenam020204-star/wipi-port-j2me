# HL4 Việt hoá: ĐỌC FILE NÀY TRƯỚC (hướng dẫn cho phiên sau)

Game: **영웅서기4 – 환영의 가면** (Heroes Lore 4, EA Mobile Korea 2010), bản WIPI của KTF và LGT.
Sản phẩm: file jar J2ME MIDP 2.0 (240x320) **chạy nguyên mã ARM gốc** trong trình thông dịch ARM viết bằng Java, kèm các dịch vụ WIPI-C được giả lập bằng HLE, và **đã Việt hoá toàn bộ text**.

## 0. Quy ước với người dùng (Mr NAM), BẮT BUỘC
- **Chỉ gửi file .zip** cho người dùng, không gửi jar/jad rời (đóng jar + jad vào một zip rồi gửi).
- Trả lời bằng tiếng Việt, ngắn gọn.
- **Bản chuẩn hiện tại là `release/HL4_KTF_VI_ui7.jar`** (ui5 + sửa lỗi mất save khi save lớn lên: db 6 xoá/7 đổi tên, tự khôi phục từ file `chicken`; RMS xoá store cũ rồi ghi mới; dòng chẩn đoán lưu bật bằng `HL4_SAVEDBG=1 ./make.sh KTF 15`): bản KTF, font **15px**, phím mềm trái = CLR/Quay lại, **giới hạn 27 fps + AOT mở rộng**, **bỏ phần online: server giả lập offline, cửa hàng cash miễn phí, DES chạy trên host**, **logo NSX = ảnh NAMP, màn Nhân vật mới toàn màn hình, ảnh tiêu đề Heroes Lore 4 của người dùng (img/src/title.png, nguồn title_user_src.png, `img/prep_title.py` cắt + chỉnh màu theo ảnh gốc), âm thanh đã chuyển sẵn sang .mid/.wav thuần J2ME, giải mã ADPCM chuẩn ffmpeg, hệ thống âm thanh pool/preload không trễ, lưu game ghi nguyên khối khi đóng file + RMS có bản dự phòng**. Bản trước đó (fixCLR) được người dùng đánh giá "chạy oke nhất". Mọi sửa đổi sau này lấy bản mới nhất làm gốc.
- Khi người dùng nói "chỉ fix X" thì chỉ đổi đúng X, không đổi gì khác.

## 1. Khôi phục môi trường (khoảng 1 phút)
```bash
mkdir -p /home/claude/work && cd /home/claude/work
unzip -q <gói>.zip -d /tmp/p && cp -r /tmp/p/HL4_project/. /home/claude/work/   # thư mục gốc gói = /home/claude/work
./setup.sh          # bung LGT.zip/KTF.zip -> lgtjar/ ktfjar/, biên dịch hl4j/build/test2 (harness headless)
./make.sh KTF 15    # overlay tiếng Việt + jar  -> dist/HL4_KTF_VI.jar/.jad   (all = cả KTF và LGT)
```
Yêu cầu: JDK 11+ (có `javac`, `jar`) và python3. Các script dùng **đường dẫn tuyệt đối `/home/claude/work`**, nên phải đặt đúng chỗ đó.
Đã kiểm chứng: `./make.sh KTF 15` cho ra jar trùng nội dung với bản trong `release/`.

## 2. Việc hay gặp: làm ở đâu
| Việc | Sửa ở đâu | Build lại |
|---|---|---|
| Đổi giới hạn fps | manifest `HL4-FPS` trong `hl4j/build.sh` (0 = không giới hạn) | `./make.sh KTF` |
| Tăng tốc (AOT) | `hl4j/tools/regen_ktf_aot.sh` (profile trong `hl4j/profiles/`), xem báo cáo §8 | `./make.sh KTF` |
| Cửa hàng offline / server giả | `hl4j/src/core/hl4/ktf/FakeServer.java` (danh mục `CATALOG`), `KtfRuntime.net()`; báo cáo §9 | `./make.sh KTF` |
| Logo NSX / ảnh tiêu đề | `img/src/logo_namp.png`, `img/src/title.png` (290x199); công cụ `img/bm.py`, `make_logo.py`, `make_title.py` | `./make.sh KTF` |
| UI mới (Nhân vật, sắp tới Túi đồ) | `hl4j/src/core/hl4/core/UiOverlay.java`; báo cáo §10 | `./make.sh KTF` |
| Âm thanh (.mid/.wav) | `hl4j/test/src/SndConvert.java` (make.sh gọi), phát ở `midp/Sound.java`; báo cáo §11 | `./make.sh` |
| Đổi phím | `hl4j/src/midp/hl4/midp/GameCanvas.java` → `wipiKey()` | `./make.sh KTF` |
| Sửa câu dịch | `vi/tr/out/*.json` (key = id trong `vi/catalog.json`), chạy `vi/tr/check.py` | `./make.sh` |
| Thuật ngữ | `vi/tr/thuat-ngu.tsv`, văn phong: `vi/tr/HUONG-DAN-DICH.md`, `vi/tr/phan-tich-vai.md` | – |
| Đổi font | `vi/font/` (font_15px.bin mặc định, font_10px), `./make.sh KTF 10` | – |
| Lỗi hiển thị/ngắt dòng chữ | `hl4j/src/core/hl4/core/TextEngine.java` | `./make.sh` |
| Lỗi giả lập (API WIPI) | `hl4j/src/core/hl4/{lgt,ktf}/*Runtime.java`, `core/Runtime.java` | `./make.sh` |
| Vá nhanh 1 class vào jar chuẩn | build rồi `zip` đè `hl4/...class` vào bản copy của jar chuẩn, tạo lại .jad (MIDlet-Jar-Size) | – |

Chạy thử không cần giả lập (headless, xuất PNG):
```bash
HL4_VI=vi/build/ktf/vi HL4_RES=vi/build/ktf java -cp hl4j/build/test2 RunHeadless KTF.zip 30000 5000 /tmp/out "8000:OK,10000:DOWN,12000:OK"
```
Tên phím: UP DOWN LEFT RIGHT OK LSK RSK CLR 0-9 # *. Trong harness đây là **mã WIPI trực tiếp**, không đi qua ánh xạ của GameCanvas. `monkey:<seed>` = bấm ngẫu nhiên. Các biến debug khác xem `BAO-CAO-KY-THUAT.md` §6.

## 3. Việc còn tồn đọng
0. **Tiếp theo:** màn Túi đồ kiểu game tham chiếu (lưới 8 cột, các tab, nhiều túi hơn). Cần tìm cấu trúc danh sách vật phẩm trong bộ nhớ và bảng icon `ITM/_ITM_ICN`, xem báo cáo §10. Ảnh tiêu đề đã thay.
1. Chữ Hàn trong **ảnh** (logo 영웅서기4, một số tiêu đề/nút dạng ảnh) chưa Việt hoá.
2. Hộp thông tin (info box) dùng `;` để ngắt dòng cứng, nên với font Việt có dòng dài, dòng ngắn không đều.
3. Font 15px dùng khoảng cách dòng 13px (hơi chật).
4. Nên rà lại tính thống nhất của bản dịch và chơi thử dài hơn (đặc biệt tuyến Lurain).
5. Bản LGT chưa được người dùng xác nhận trên máy/giả lập thật (headless thì chạy tốt).

Chi tiết kỹ thuật xem **`BAO-CAO-KY-THUAT.md`**.
