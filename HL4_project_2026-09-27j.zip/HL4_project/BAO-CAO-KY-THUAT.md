# Báo cáo kỹ thuật: HL4 WIPI → J2ME + Việt hoá

## 1. Tổng quan kiến trúc
```
 jar J2ME (MIDP 2.0 / CLDC 1.1)
 ├─ hl4/midp/*        HL4Midlet, GameCanvas (vòng lặp, phím, vẽ, RMS, âm thanh), Sound
 ├─ hl4/core/*        Runtime (dùng chung), Heap, Gfx16 (RGB565), Smaf (MMF→MIDI/WAV), TextEngine + VnFont (Việt hoá)
 ├─ hl4/cpu/*         Cpu (ARMv5TE: ARM + Thumb, user mode), Memory (trang 64KB), Aot (giao diện)
 ├─ hl4/lgt/*         LgtRuntime: nạp binary.mod (ELF32 ARM), bảng import WIPI-C của LGT
 ├─ hl4/ktf/*         KtfRuntime + KJvm (JVM tối giản theo layout bộ nhớ KTF) + KtfPlatform (org.kwis.msp.lcdui.*)
 ├─ hl4/aot/{Ktf|Lgt}Aot  vòng lặp nóng dịch tĩnh Thumb→Java (sinh bởi hl4j/tools/aotgen.py), cho kết quả bit-exact
 └─ tài nguyên gốc của game + overlay tiếng Việt (vi/f10.bin, vi/dict.txt, file dữ liệu đã dịch, binary đã vá chuỗi)
```
Nguyên tắc: **không viết lại logic game**. Mã máy ARM gốc (LGT: `binary.mod`, KTF: `client.bin387872`) chạy trong trình thông dịch. Chỉ các API của nền tảng (WIPI-C, WIPI-Java của KTF) được thay bằng code Java trên host (HLE).

Cơ chế gọi host: một stub là địa chỉ S (căn 4 byte) chứa lệnh Thumb `SVC #0xFF` (0xDFFF) và **id** 32-bit tại S+4. Mã khách nhảy tới S|1. id = `category<<16 | index`.

Bố cục bộ nhớ khách (Runtime): HEAP 0x02000000 (64MB ảo, cấp trang lười), STACK_TOP 0x08000000 (1MB), STUB 0x7F000000.
Category: CAT_INTERNAL 0x7F00, CAT_HLE 0x7E00 (hàm game bị thay bằng host). LGT: INIT 0x100, WIPIC 0x1FB, STDLIB 0x001. KTF: INIT 0x300, JAVA 0x302, WIPIC 0x310+bảng.

### LGT
- `binary.mod` là ELF32. Phần .text được map ở 0x1000 (vị trí trong file = addr−0x1000+0x34), phần data ở 0x1400000 (vị trí trong file = addr−0x1400000+0x93970).
- Tài nguyên nằm trong `res/` của jar. AID 0002D74B, PID PD140249 (đọc từ app_info rồi ghi vào manifest).
- DES của chính game: decrypt 0x8e28, encrypt 0x8e9c (Thumb). `test/src/HL4Tool.java` gọi hai hàm này để giải/mã hoá file dữ liệu.

### KTF
- `client.bin387872` được map ở IMAGE_BASE 0x100000 (vị trí trong file = addr−0x100000). Mã PIC có GOT (sl) = 0x189cb8.
- Gồm các lớp Java đã được biên dịch AOT sẵn cùng mã native của Clet. KJvm dựng class/object theo layout KTF (tham khảo emulator "wie" của dlunch trên GitHub). Các lớp nền tảng (java.lang.*, org.kwis.msp.lcdui.*) là method host.
- Manifest ghi: HL4-AID 010100D4, HL4-PID PD008712, HL4-Binary client.bin387872.

### Phím (GameCanvas.wipiKey)
Mã WIPI: UP −1, DOWN −2, LEFT −3, RIGHT −4, FIRE −5, LSK −6, RSK −7, **CLR −16**, số 0–9 và `*` `#` giữ nguyên mã ASCII. Sự kiện: press 502, release 503, repeat 504.
**Ánh xạ hiện tại (theo yêu cầu người dùng): phím mềm trái vật lý (−6, Motorola −21) → CLR (−16).** Các phím −8, 8 (backspace), 27 (esc) cũng → CLR. RSK −7 giữ nguyên. Hệ quả: game không còn nhận được LSK của WIPI; nếu có màn hình cần LSK thật thì phải bàn lại với người dùng.

### Lưu game, âm thanh, hiển thị
- Lưu game: Host.storageRead/Write → RecordStore (mỗi file một store). Định dạng save giống bản gốc.
- Âm thanh: MMF (SMAF) → MIDI/WAV (Smaf.java), phát bằng MMAPI Player.
- Framebuffer RGB565 trong bộ nhớ khách → int[] ARGB → vẽ (có scale nguyên nếu màn hình lớn).

### Hiệu năng
- Harness headless chạy khoảng 45 MIPS trên JVM desktop. Trên thiết bị/giả lập J2ME chậm hơn nhiều, nên có AOT.
- AOT: chạy headless với `HL4_PROFILE` để lấy profile, sau đó `aotgen.py --bin <ảnh code> --base <addr> --class KtfAot --out src/aot/hl4/aot/KtfAot.java <profile>`. Chỉ các vùng vòng lặp không có call/return/host-call mới được dịch. Kết quả đã kiểm chứng bit-exact so với trình thông dịch. Nếu thiếu class AOT thì GameCanvas tự bỏ qua.

## 2. Việt hoá: engine chữ (TextEngine + VnFont)
- Engine chữ gốc (cùng mã C ở cả hai bản): ASCII 5x11 (advance 6) và Hangul EUC-KR 2 byte (10x11, advance 11), cộng các mã điều khiển: `;` xuống dòng, ` `/`=` là khoảng trống 4px, các mã màu `&|${}'"\`^<`.
- Phần HLE thay 3 hàm bố cục chữ: **measure, fit lines (ngắt dòng/trang), draw**, cộng draw có màu.
  - LGT: hookThumb 0x2f484 (measure), 0x2f524 (fit), 0x2fe78 (draw), literal 0x1e4f0 → stub draw màu. Hàm gốc: drawOrig 0x2f71c, colorCode 0x2f680, setColor 0x2f420, ctx 0x8f10, putPixel 0x2f398.
  - KTF: hookThumb 0x133f74 / 0x13495c / 0x134840; patchBL 0x12277c → stub gần ở 0xF0000. Hàm gốc: drawOrig 0x13405c, colorCode 0x133e2c, setColor 0x133dd0, ctx 0x108a40, putPixel 0x133d24; addrEnabled/addrCodes đọc qua GOT+0x270/0x274.
- Mã hoá chữ Việt: mỗi **âm tiết/từ** (hoặc ký tự có dấu) = 2 byte, gồm lead 0xC9.. và trail 0xA1.. (94 mã mỗi lead). Chỉ số k = (lead−0xC9)*94 + (trail−0xA1) trỏ vào dòng thứ k của `vi/dict.txt`. Nhờ vậy mọi đoạn xử lý "byte cao = ký tự 2 byte" của game vẫn đúng, và độ dài byte gần bằng tiếng Hàn. ASCII giữ 1 byte.
- Font: định dạng "fontcus" (u2 utfLen, charset, s1 height, s1[n] advance, atlas 1bpp LSB-first). yOff = 8 − baseline (baseline lấy từ chữ 'H'). spaceW = advance(' ').
- Ngắt dòng theo từ, dùng chung cho measure/fit/draw để phần phân trang của game khớp. Bug đã sửa: wordWidth() ghi đè trạng thái token, nên giờ phải lưu/khôi phục tt/tlen/tw/tcode.
- Chữ Hàn còn sót và chữ ASCII nhỏ vẫn vẽ bằng hàm gốc (mỗi lần một glyph).

## 3. Việt hoá: pipeline dữ liệu (thư mục vi/)
1. `extract.py` gom mọi chuỗi Hàn (EUC-KR) vào `catalog.json` (19154 mục dùng, có id, kind, src, speaker, cap).
2. `make_chunks.py` chia thành `tr/chunks/*.json` để dịch. Bản dịch nằm ở `tr/out/*.json` và đã đủ 100%, `check.py` báo OK hết.
3. `build_vi.py` tạo overlay trong `vi/build/{lgt,ktf}` (cấu trúc thư mục = gốc jar; LGT có tiền tố `res/`):
   - scn hội thoại `MAP/SC/*_scn` (mã hoá DES), các bảng tdf/GMenu/NPCUI/EVENT_POP/HELP/FREE/UseInfo, `_tdf_TIP`, `NPC/NAME_DAT`, tên bản đồ trong `MAP/M/_MAP_M_*`;
   - các họ record (mã hoá DES): QUEST, ITM, ESDAT/BSDAT, COMBINE, GUARDIANSHOP, H_S*/H_SS/H_BH. Chuỗi dạng u1 len + bytes, record dạng u2 len, sau đó pad đủ bội 8 rồi mã hoá bằng DES của game (HL4Tool);
   - chuỗi trong binary: vá tại chỗ theo `vi/data/{lgt,ktf}_binstr.json` (addr, slot). 117 chuỗi mỗi bản. Chuỗi dịch phải vừa slot, nếu không thì giữ nguyên tiếng Hàn và in "too long";
   - chép font vào `vi/f10.bin` (tên file giữ nguyên dù là font 15px) và `vi/dict.txt`.
   - `vi/dec/` là bản giải mã sẵn của các file DES (tạo bằng `java -cp hl4j/build/test2 HL4Tool des decrypt <in> <out> <files…>`).
4. `hl4j/build.sh <LGT|KTF> <zip gốc> <outdir>` với env `OVERLAY` và `SUFFIX`: ecj (source 1.3 / target 1.2) → ProGuard (preverify, không obfuscate) → ghép jar gốc + overlay + manifest/jad.
5. `make.sh` (thư mục gốc) chạy bước 3 và 4.

Quy tắc dịch (quan trọng khi sửa câu): xem `vi/tr/HUONG-DAN-DICH.md`. Tóm tắt: giữ nguyên số lượng các mã điều khiển; không dùng `_`, ngoặc kép cong, gạch dài; `;` là xuống dòng; tên riêng theo `thuat-ngu.tsv`; `cap` là giới hạn byte.

## 4. Lịch sử bản phát hành
- test1: bản VI đầu tiên (font 10px v2).
- test2: có hai biến thể _VI (10px) và _VI15 (15px).
- **fixCLR (bản chuẩn)**: KTF, font 15px, LSK→CLR. Người dùng xác nhận chạy tốt nhất. File: `release/`.

## 5. Tài nguyên ngoài gói
- `wie` (emulator WIPI viết bằng Rust của dlunch, GitHub): tài liệu tham khảo cho layout KTF, SMAF, API. Không kèm vì nặng 850MB.
- FreeJ2ME: dùng để thử jar trên PC (test harness nằm ở `hl4j/test/fj`). Không kèm mã nguồn.
- Bộ công cụ font của người dùng (Tool_Vi_t_Ho__NAM.P.zip) đã chép nội dung vào `vi/font/` (README, fontcus.java, pixeltext-kit, font_10px, font_15px.bin).

## 6. Biến môi trường của harness RunHeadless
`HL4_VI=<thư mục có f10.bin, dict.txt>` bật engine chữ Việt; `HL4_RES=<overlay>` đè tài nguyên; `HL4_DEBUG`, `HL4_TEDEBUG` (log engine chữ), `HL4_TRACE=<svc hex,…>`, `HL4_SVCLOG`, `HL4_CALLS=<addr hex,…>` (+`HL4_CALLS_FILTER`, `HL4_CALLS_STK`), `HL4_WATCH=<tên file>` (theo dõi truy cập vùng nhớ chứa file tài nguyên), `HL4_WATCHADDR`, `HL4_PROFILE` (profile cho AOT), `HL4_AOT` (bật AOT trong harness), `HL4_JTRACE` (trace KJvm); `-Dipms=` số lệnh/ms của đồng hồ ảo, `-Dstorage=` thư mục save.
Lưu ý: chạy headless tới màn hình tiêu đề có thể hiện "Mất kết nối với máy chủ" nếu bấm OK sớm vào mục mạng. Đây là hành vi bình thường vì không có mạng.

## 7. Cấu trúc gói
```
README.md  BAO-CAO-KY-THUAT.md  setup.sh  make.sh  LGT.zip  KTF.zip (bản gốc)
release/   HL4_KTF_VI_fixCLR.jar/.jad (bản chuẩn)
hl4j/      src/{core,midp,aot}  test/src (RunHeadless, HL4Tool, CpuTest...)  tools/aotgen.py  build.sh  tbuild.sh
tools/     ecj, proguard, stub CLDC/MIDP, microemulator
vi/        extract.py make_chunks.py build_vi.py fmt.py binstr.py catalog.json dec/ data/ font/ tr/
```

## 8. Hiệu năng và giới hạn 27 fps (phiên 2026-09-27)
**Nguyên nhân tụt khung hình:** vòng lặp game đặt lại timer 1 ms và mỗi callback là 1 khung hình, logic chạy theo khung hình, nên game chạy nhanh hết mức CPU cho phép và tốc độ game phụ thuộc fps. AOT cũ chỉ dịch được vòng lặp đo từ màn hình tiêu đề/menu. Hàm vẽ sprite trong suốt (alpha 4-bit, 0x10f404) chiếm khoảng 30% thời gian khi chơi nhưng chạy bằng trình thông dịch. Ngoài ra khoảng 10% lệnh còn thông dịch nhưng chiếm khoảng 60% thời gian.

**Giới hạn fps** (`Runtime.setFrameLimit`, manifest `HL4-FPS: 27`, harness dùng `HL4_FPSCAP=27`): timer của game đặt lại với timeout nhỏ hơn 1 khung thì bị lùi để hai callback liên tiếp cách nhau ít nhất 1000/27 ms. Lịch chạy theo lưới thời gian cố định (µs), chỉ bắt kịp khi trễ dưới nửa khung, nên trung bình đúng 27 fps. Khung chậm hơn thì không bị chờ thêm.

**AOT mới** (`hl4j/tools/aotgen.py`, `tools/regen_ktf_aot.sh`):
- `--coldcut`: bỏ nhánh lạnh khỏi region vòng lặp; `--maxinsns 1000` để phủ được vòng blit alpha lớn;
- loại bỏ cờ chết: phân tích liveness của n/z/C/v, chỉ tính cờ khi còn được đọc;
- `--funcregions`: dịch cả code nóng không phải vòng lặp. Region thoát ở BL/BLX (có đặt r14), BX/BLX thanh ghi, POP {pc}; lối ra sang ARM được `Cpu.runLoop` xử lý qua bit0;
- bảng entry lưu dạng chuỗi (để `<clinit>` nhỏ);
- **loại trừ các địa chỉ bị HLE vá lúc chạy** (0x133f74, 0x13495c, 0x134840, 0x12277c). Nếu quên, AOT sẽ chạy mã gốc thay cho hook. `Runtime.hookThumb/patchBL` còn gọi `cpu.aotBlock()` để chặn thêm lúc chạy.
- Profile: `hl4j/profiles/ktf_*.txt` (gameplay, đi lại/hội thoại, menu).
Kết quả trên PC: AOT phủ khoảng 99% số lệnh khi chơi. Đoạn chơi 15 s: bản cũ 20,5 s thực → bản mới 2,8 s. Đã kiểm tra **bit-exact** với trình thông dịch (cùng icount, cùng ảnh khung, cùng thống kê svc) trên 2 kịch bản 150 s và 500 s.
**Host:** `Gfx16.copy` không cấp phát mảng mỗi lần gọi nữa (memmove theo từng từ), `fillRect` điền theo từ, `toArgb` đọc 2 pixel mỗi lần.
**Công cụ kiểm chứng:** `HL4_AOTCHECK=<icFrom>,<icTo>` chạy lại mọi region AOT trong khoảng đó bằng trình thông dịch và in chỗ lệch (`AOTCHECK ...`). `HL4_FPS=1` in fps, số lệnh/khung, thời gian thực.
LgtAot (bản LGT) chưa được sinh lại.

## 9. Bỏ online, server giả lập offline (phiên 2026-09-27)
**Mạng của game (KTF):** TCP tới 210.222.18.31:8894. Bảng mạng WIPI-C của KTF dài hơn 30 hàm, phần tiếp theo rơi vào bảng T_IF11: idx 30 = socket connect (fd, addr, port, ?, cb, param), trả về M_E_WOULDBLOCK = -19 rồi gọi cb(fd, 0, param); 31 = write, 32 = read (-19 khi chưa có dữ liệu), 33 = close. Game dùng thêm `MC_netSetReadCB` (13).
Gói tin: `u32 len (tính cả header) | u8 major | u8 minor | payload`. Hàm phân phối gói 0x1696e0: major 1 → 0x169444, 5 → 0x1678a8 (bảng nhảy theo minor-3), 20 → 0x167630, 100 → 0x167414. Trong bộ đệm nhận, gói nằm ở buf+12, payload bắt đầu từ buf+18.
Trạng thái kết nối = byte `[[GOT+0x18c]]+0xdb` (0x189e44 → G): 5 = đồng ý SMS ở màn tiêu đề, 2 = khôi phục nhân vật (#), 6 = mua hồi sinh, 0 + cờ G+0xd4 = cửa hàng (phím phải).

**`hl4.ktf.FakeServer`** trả lời các gói sau:
- 1/1 hello → [0]; 1/0x3d login → [0]; 1/0x3e → [0,0,văn bản]; 1/0x50 (đồng ý SMS) → [1,0,"Đã lưu lựa chọn."]. Payload[0] ≠ 0 nghĩa là có thông báo; cờ được lưu nên lần sau không hỏi lại.
- 5/63 danh mục cửa hàng: [cờ, cờ, u16 n, n bản ghi × 37 byte]. Bản ghi: [0] tab; [1..8] id (gửi lại ở 5/66); [9..16] mã sản phẩm (gửi lại ở 5/64 và 5/107, ta đặt = loại, số thứ tự); [17] loại, [18] số thứ tự vật phẩm; [19] số lượng; [20] cờ; [21..24] giá (0).
- 5/66 (mua) → [1,0,msg] để game đi tiếp sang thanh toán 5/64. 5/64 hoặc 5/107 → [1, L, msg(L), code]. code 0xff = trao vật phẩm đã chọn (0x140248). Code khác = một mục của `_ITM_CASH_RANOMBOX` (dùng cho Rương báu 25..28; 0x129760 phát nội dung).
- 5/106 số dư KOIN → [1, L, msg, u32 số dư, u32 giá]; 5/110, 5/111 (hồi sinh) → [1,0,msg].
- Gói khác: server "ngắt". **Kho mạng và khôi phục nhân vật bị từ chối ngay ở `MC_netConnect`**: chỉ trạng thái 5, 6 và cửa hàng mới được kết nối; các trạng thái khác nhận cb(-1) như khi không có mạng, và game hiện "Bản offline: không hỗ trợ" (chuỗi 7252).
- Danh mục mặc định: 15 vật phẩm cash, loại 8, số thứ tự 15..29 (Elixir ×5, Sách hồi sinh ×3, Đá tinh luyện cao cấp ×5, các loại bùa, Thêm ổ khảm, Túi hành trang, Tự nhặt đồ, các loại đặt lại, Rương báu ×4 loại). Tất cả miễn phí.
- Chuỗi hiển thị do server gửi được mã hoá bằng `TextEngine.encode()` (cùng cách mã hoá với build_vi). Bản tiếng Hàn dùng ASCII.
- Harness: `HL4_ECHO=1` (server chỉ phản hồi lại đúng gói nhận được), `-Dhl4.fs.box=<code>` (ép mã rương). Log `[FakeServer] req M/m hex`. Game tự in tên giao thức qua printk.
- Chưa kiểm tra trong headless: mua hồi sinh khi chết (5/110-111), thanh toán KOIN, NPC "Mạng" (kho mạng; dự kiến bị từ chối như khôi phục nhân vật).

**DES trên host:** hàm 0x108500 (16 vòng Feistel trên mảng bit kiểu int) được hook thành HLE 16 (`KtfRuntime.desRounds`). Bảng E/P/S/khoá con đọc từ bộ nhớ game qua chuỗi con trỏ GOT (literal 0x1086a8/ac/b0/b4). `test/src/KtfDesCheck.java` so sánh giải mã và mã hoá của 504 file (823 KB) giữa mã game và HLE: khớp 100%. Hệ quả: mở cửa hàng từ khoảng 650 triệu lệnh (≈6,5 s ảo) còn tức thì, tải map và save cũng nhanh hơn. Trong AOT đã loại trừ vùng 108500-108508. Lưu ý: vì HLE không tăng icount nên các lần chạy harness không còn khớp bit-exact với bản cũ (chỉ lệch về thời gian ảo).

## 10. Ảnh, logo và UI mới (phiên 2026-09-27)
**Định dạng ảnh `*_BM`** (`img/bm.py`): u32 số ảnh, mỗi ảnh gồm u32 kích thước + thân. Thân: u8 kiểu (0x0b = 4 bpp, nibble cao đứng trước; 0x0c = 8 bpp), u16 w, u16 h, u16 aux (thường bằng w), u16 số màu, bảng màu RGB565 (màu 0 = 0xF81F trong suốt), rồi các điểm ảnh. Các hàm `parse`, `decode`, `encode` (lượng tử hoá còn 255 màu, có dither), `blank`, `build`.
- **Logo NSX:** file `l/_LOGO` có 6 ảnh; ảnh 4 là logo EA 86x98. Màn logo vẽ ảnh 4 ở x căn giữa, y = 160 − 3h/4. `make_logo.py` làm các ảnh khác trong suốt và đặt ảnh 4 thành 240x640, tranh của người dùng nằm ở nửa dưới, nhờ vậy phủ kín màn 240x320. Nguồn: `img/src/logo_namp.png`, `build_vi.py` tự áp cho cả KTF và LGT.
- **Ảnh tiêu đề:** `tdf/TITLE_BM` là một ảnh 290x199 8 bpp (chữ logo in liền vào nền), vẽ ở vị trí (−18, 16); vùng thấy được là cột 18..257. `make_title.py` nhận PNG (tự đưa về 290x199). Nếu có `img/src/title.png` thì `build_vi.py` tự đóng gói. Gói xuất ra cho người dùng vẽ: `HL4_logo_tieude_de_ve.zip`.

**UI thay thế (`hl4.core.UiOverlay`)**, chỉ có ở bản VI: `TextEngine.Sink` nhận mọi lần vẽ chữ (toạ độ + chuỗi đã giải mã) trong một khung hình. Lúc flush (`ui.compose` trong KtfRuntime và LgtRuntime), nếu nhận ra một cửa sổ thì vẽ lại toàn màn hình. Logic và phím vẫn do game xử lý.
- **Nhân vật (Status):** nhận diện qua chữ "Status" ở (100..105, 80..86). Các giá trị lấy theo vùng toạ độ chữ gốc: tên (40..135, 98..108), chủng tộc, lớp, Level (x > 170, y 104..112), HP/SP/EXP/NEXT, 8 chỉ số (y 123..186, bước 9), điểm (40..100, 221..228), STR/AGI/VIT/INT. Ô đang chọn: kiểm tra điểm vàng ở cạnh trái hộp (x 127..129 và 179..181; y 215 và 229). Chân dung: chép vùng (33, 100, 44x54) của khung gốc, phóng x2.
- **Túi đồ (chưa làm):** game chỉ vẽ lưới 4 cột của túi đang mở, nên để có lưới 8 cột như tham chiếu phải đọc dữ liệu thật. Đầu mối: đối tượng vật phẩm có +0x20 loại, +0x22 số thứ tự, +0x25 số lượng (xem 0x16747c và 0x140248 = thêm vào túi); icon ở `ITM/_ITM_ICN`, `_ITM_SD*`. Dữ liệu người chơi nằm quanh 0x19a28c (HP int; STR/AGI/VIT/INT dạng byte ở 0x19a36e và 0x19a390).
- Công cụ harness: `HL4_TEXTLOG=<ms>` in mọi chữ được vẽ trong 60 ms kể từ thời điểm đó; `HL4_DUMPMEM=<ms>` ghi `mem.bin` (các trang: số trang + 64 KB) và `mem.png`; đọc bằng `tools/mem.py` (`load`, `find_seq`).

## 11. Âm thanh thuần J2ME (phiên 2026-09-27)
- Lúc build, `SndConvert` (make.sh gọi, dùng `hl4.core.Smaf`) chuyển mọi `SND/*_MMF` thành `SND/<tên>.mid` (track score → SMF format 1) hoặc `SND/<tên>.wav` (PCM 16-bit, 8 kHz, mono). KTF: 20 .mid + 21 .wav; LGT: 20 + 22. Không có file nào lỗi.
- Tên gốc `SND/*_MMF` được thay bằng stub 22 byte: `"HL4SND\0" + đường dẫn tài nguyên` (LGT: `/res/SND/...`). Game vẫn nạp và truyền dữ liệu như cũ, vì game không đọc nội dung MMF (số lời gọi media trùng khớp với bản cũ). `Sound.create` thấy stub thì đọc thẳng .mid/.wav trong jar và phát bằng MMAPI (`audio/midi`, `audio/x-wav`). Không còn chuyển đổi lúc chạy.
- Smaf.java vẫn nằm trong jar, chỉ để phát file MMF chưa chuyển (bản build không có overlay).
- Muốn thay nhạc: đặt file .mid/.wav cùng tên vào overlay (sau bước SndConvert trong make.sh), giữ nguyên stub.

## 12. Sửa âm thanh bị nhỏ/mất, hệ thống âm thanh mới (phiên 2026-09-27)
- **Lỗi:** bộ giải mã Yamaha ADPCM trong `Smaf.adpcm` dùng bảng bước 57..153 >>6 (0,8906 thay vì 230/256) cộng bộ lọc DC, nên biên độ tụt dần: nhiều hiệu ứng nhỏ hơn 10–25 dB (EFF_07 rms 724 → 9918, EFF_10 188 → 3457). Đây có thể là nguyên nhân mất tiếng súng.
- **Sửa:** dùng đúng thuật toán `adpcm_yamaha` của ffmpeg (bảng 230,230,230,230,307,409,512,614 >>8, bước kẹp trong 127..24576, nibble thấp trước), bỏ bộ lọc DC, thêm fade-out 5 ms chống tiếng click. Đã so với `ffmpeg -f mmf`: 21/21 file trùng từng mẫu (trừ đoạn fade).
- **`hl4.midp.Sound` viết lại:** mỗi file là một bank được cache, không tạo lại khi game làm "stop, free, set data, play" cho từng hiệu ứng.
  - Hiệu ứng có pool tối đa 3 player đã prefetch, player thứ 2 và 3 chỉ tạo khi cần phát chồng (bắn liên tục).
  - Hiệu ứng một lần phát hết, không bị cắt khi game gọi stop/free; nhạc và âm lặp vẫn theo đúng stop/free.
  - Tối đa 6 tiếng hiệu ứng cùng lúc; chỉ giữ 24 player (bỏ player lâu không dùng nhất); nhạc nền chỉ giữ một bài.
  - Lúc khởi động, một luồng nền prefetch sẵn mọi file .wav theo `SND/list.txt` (do SndConvert ghi).
- Đã test logic bằng MMAPI giả (`/tmp/sndmock`): bắn liên tục cách nhau 120 ms thì mỗi phát đều start ngay, xoay vòng pool. **Chưa nghe thử trên máy thật.**
- Harness: `HL4_SNDLOG=1` in create/play/stop/free theo tên file.

## 13. Lưu game (phiên 2026-09-27)
- Cách game lưu (KTF): file `kickass` (khoảng 2248 byte). Mỗi phần: open mode 8 → seek → ghi dữ liệu → seek 0 → ghi thư mục 200 byte → close. Lưu một slot gồm 3 lượt như vậy. Mode: 1 = đọc, 2 = tạo mới, 4 = xoá rỗng, 8 = đọc/ghi.
- Bản cũ ghi cả file xuống RMS ở **mỗi lần** stream write, và mỗi handle giữ một bản sao dữ liệu riêng. Nếu máy dừng giữa chừng hoặc có handle cũ thì có thể lưu dở hoặc đè dữ liệu cũ.
- **Mới (`KtfRuntime`):** mỗi tên file dùng một bộ đệm `FileBuf` chung cho mọi handle. Ghi chỉ vào bộ nhớ; khi close mới ghi nguyên khối xuống storage, tức mỗi phần lưu được ghi trọn một lần. `flushStorage()` được gọi khi app bị tạm dừng, ẩn hoặc thoát.
- **RMS (`GameCanvas`):** store `hl4<tên>` cộng bản dự phòng `hl4<tên>~`. Tìm record theo enumeration thay vì mặc định id 1. Ghi xong đọc lại để so; nếu sai thì xoá store, tạo lại rồi ghi tiếp. Khi đọc, nếu store chính hỏng thì lấy bản dự phòng.
- Đã test headless: lưu lúc 146 s rồi lưu lại lúc 206 s, chạy lại game thì slot hiện play time 1:41 (bản mới nhất) và nạp đúng vị trí. **Chưa test RMS trên máy thật.** Lưu ý: xác nhận "Lưu game? Có" phải bấm OK/5; phím mềm trái giờ là CLR (huỷ).
- LGT (`LgtRuntime`) vẫn dùng kiểu ghi cũ, chưa sửa.

### 13b. Lỗi "mua cash rồi load bị lùi về trước giao dịch" (ĐÃ SỬA ở ui7)
- Người dùng (ui5): mua Rương báu trong shop, lưu (System > Lưu), rồi System > Main menu > load thì ra trạng thái trước khi mua.
- **Không tái hiện được trên harness** (đã thử: Elixir, Túi hành trang, Tự nhặt đồ, Rương báu với mã 0..4; lưu tay, load qua Main menu và qua khởi động lại; có/không AOT; FPS cap 27; đồng hồ 2026). Mọi trường hợp đều load đúng trạng thái mới.
- Game **không** kiểm tra đồ với server khi load. Mỗi phần save = 16 byte hash (hàm 0x1434b4) + dữ liệu mã hoá DES (0x1089b0 / 0x108920). Đọc phần (0x176778) giải mã rồi so hash. CERTIDATA (0x143504) chỉ lưu PHONENUMBER (ta trả ""). Mua xong game tự lưu GameSave + SlotSave ngay khi nhận 5/64. Có gói 20/70 gửi GameSave lên server (0x166104, sao lưu nhân vật), nhưng bản offline đã chặn.
- Load qua Main menu đọc từ `FileBuf` trong bộ nhớ, không qua RMS. Nếu lỗi xảy ra theo đường này thì game đã không ghi, hoặc đã ghi dữ liệu cũ.
- **ui6 (theo yêu cầu người dùng): không ghi đè nữa.** `GameCanvas.storageWrite` xoá hẳn store bản dự phòng `hl4<tên>~` rồi tạo lại và ghi, sau đó làm y như vậy với store chính `hl4<tên>`; nếu lỗi thì thử lại 1 lần. Lúc nào cũng còn ít nhất một bản đầy đủ. Đọc: store chính rỗng hoặc hỏng thì lấy bản dự phòng. Bỏ hẳn `RecordEnumeration`: FreeJ2ME có lỗi `nextRecordId()` không tiến nên vòng lặp cũ treo. Giờ đọc bản ghi đầu tiên có thật, từ id 1 tới `getNextRecordID()-1`. Đã test với RMS của FreeJ2ME: ghi 5 lần liên tiếp đọc lại đúng, xoá store chính thì đọc được từ bản dự phòng.
- **Dòng chẩn đoán (có trong ui6)** (manifest `HL4-SAVEDBG: 1`, harness `HL4_SAVEDBG=1`): vẽ một dòng vàng trên đầu màn hình trong 5 s.
  - `GHI#n <size>B G:xxxxxx S:yyyyyy` khi ghi file. G/S là 3 byte đầu hash của GameSave (@456) và SlotSave (@1736).
  - `DOC G:xxxxxx` khi game đọc GameSave để load.
  - `LOI GHI RMS`, `DOC BAN DU PHONG` khi RMS lỗi.
  - Nhờ người dùng so G lúc lưu và lúc load.
- Harness: `HL4_VTIME=<ms>` đặt đồng hồ ảo, `-Dipms=` (qua `JOPT`) đổi tốc độ CPU ảo, `-Dhl4.fs.box=<n>` ép nội dung rương.

- **Nguyên nhân (tìm được nhờ ảnh chụp của người dùng trên ui6):** file 4040 byte, mã GameSave không đổi giữa các lần lưu. Hàm ghi phần save 0x176eb8: nếu dữ liệu mới (làm tròn lên bội 256) lớn hơn chỗ đã cấp cho phần đó (GameSave cấp 0x500 = 1280 byte, túi đồ nhiều thì vượt), game **dựng lại cả file** sang file tạm `chicken`: mở mode 2, ghi thư mục mới, chép các phần khác sang, thêm phần mới vào cuối. Sau đó gọi db hàm 6 `(kickass, 1)` = xoá file, rồi db hàm 7 `(chicken, kickass, 1)` = đổi tên. Bản cũ coi hàm 6 là no-op và **không có hàm 7** (trả -1). Vì vậy `kickass` giữ nguyên bản cũ, còn mọi lần lưu sau chỉ ghi vào `chicken`. Load thì đọc `kickass`, ra trạng thái trước khi túi đồ lớn lên (tức trước lần mua).
- **Sửa (ui7, `KtfRuntime`):**
  - db 6 với tên file = xoá file (nếu arg0 là handle đang mở thì vẫn là no-op).
  - db 7 = đổi tên: chuyển `FileBuf` sang tên mới, ghi xuống storage, xoá tên cũ.
  - mode 2 = tạo mới rỗng.
  - Lúc khởi động, nếu còn `chicken` sót lại từ bản cũ (luôn là save mới nhất) thì chép thành `kickass`, xoá `chicken`, rồi hiện dòng "KHOI PHUC SAVE MOI NHAT".
- Test headless:
  - mua 17 món: save được dựng lại 2 lần (2504 → 2760 → 3016 byte), load qua Main menu đúng, mã G lúc lưu và lúc đọc khớp;
  - storage gồm `kickass` cũ + `chicken`: khởi động lấy đúng bản mới (play time 4:21, túi đầy).
- Dòng chẩn đoán giờ tìm vị trí GameSave/SlotSave theo thư mục, không dùng offset cố định nữa. Có thêm dòng `XOA`, `DOI TEN`.
