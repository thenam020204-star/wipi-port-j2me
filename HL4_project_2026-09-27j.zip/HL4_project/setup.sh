#!/bin/bash
# Khôi phục môi trường làm việc sau khi giải nén gói dự án.
# Dự án PHẢI nằm ở /home/claude/work (các script dùng đường dẫn tuyệt đối này).
set -e
W=/home/claude/work
[ "$(cd "$(dirname "$0")" && pwd)" = "$W" ] || { echo "Hãy giải nén sao cho thư mục này là $W"; exit 1; }
cd $W
# 1) bung jar gốc (tài nguyên thô dùng cho extract/build_vi)
rm -rf lgtjar ktfjar tmpx && mkdir -p lgtjar ktfjar tmpx
unzip -q -o LGT.zip -d tmpx/l && (cd lgtjar && unzip -q -o ../tmpx/l/*.jar)
unzip -q -o KTF.zip -d tmpx/k && (cd ktfjar && unzip -q -o ../tmpx/k/*.jar)
rm -rf tmpx
# 2) biên dịch harness headless + HL4Tool (Java SE, cần JDK 11+)
(cd hl4j && ./tbuild.sh build/test2)
echo "OK: lgtjar/ ktfjar/ hl4j/build/test2 sẵn sàng. Tiếp: ./make.sh"
