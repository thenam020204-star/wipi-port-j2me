MIDlet-Name: ����2
MIDlet-Version: 1.0.0
MIDlet-Vendor: (��)������
MIDlet-Jar-URL: http://wipi.nate.com:9100/EXE/00279/28186_0066128686_3/0066128686.smf?PT=/wipijava/O00119/10000C0BEB/&SERVICE_ID=002790027928186
MIDlet-Jar-Size: 1055736
MicroEdition-Profile: M_Profile-1.0, SKTP-1.1
MicroEdition-Configuration: M_Configuration-1.0
MIDlet-X-Date: 0
MIDlet-Menu-Location:  
MIDlet-1: ����2,,TheFarm2
MIDlet-Description:  
MIDlet-Info-URL:  
MIDlet-Install-Notify: http://wipi.nate.com:9100/NOT/00279/28186_0066128686_3/KEY_10080248544223325516808?
MIDlet-X-Update-URL:  
MIDlet-Ani-Icon-URL: 36x36.xaf
MIDlet-Icon-URL: 23x23.bmp
MIDlet-Key4: 0298323fc5cebe8393785fafca171d4f
App-Type: MIDlet
DD-ProgName: 0066128686
DD-MIME-Type: application/x-wipi-jar
DD-File-Ass: jar
DD-Next-URL:  
DD-SubType:  
DD-Player-Version: 1.0.0
DD-Player-ProgName: 
DD-Player-DDURL: 
DD-Proxy-URL: wipi.nate.com
DD-Proxy-Port: 9100
DD-Attribute: 2, EXECUTABLE, SKT-GAME
DD-Protect-Count: 0
DD-DLF-ProgName: 1000026787
DD-DLF-Version: 1.0
DD-DLF-Size: 366980
DD-DLF-DownURL: 0066128686.dlf
DD-DLF-MIMEType: application/x-wipi-lib
XVM-Heap-Size: 2000000
