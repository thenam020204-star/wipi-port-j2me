# Báo cáo kỹ thuật: GrandChase LGT → J2ME (r4)

## 1. Kiểm kê
`0002D176.jar` 2,86 MB, 952 file: `binary.mod` (ELF ARM, .text 0x1000+0x432a8, .data 0x1400000+0x470, .bss 0x1500000+0x13dca8, `.raptor`), 62 `.mmf`, 271 `.pbp`, 239 `.msd`, 106 `.mgd`, 91 `.scp`, 90 `.dat`, 54 `.ymp`, 27 `.pal`, `GrandChase.xrf`, `ConstData.br`, `Font.br`, `icon.br`, `Xfont.dt`, `GET.dt`, `menu.tx`, `npcmenu.tx`, `MLibID.sig`, `ZIM_LGT_20_ARM.lib`. `app_info`: PID PD138681, WIPIVer 1, MClass Clet, MaxThread 3. Mục tiêu CLDC1.1/MIDP2.0 (stub jar kèm `tools/`).
Entry: `CletRegister start=0x1069 paint=0x1135 event=0x1089`.

## 2. Phương pháp
Không viết lại logic; chạy ARM gốc (Cpu ARMv5TE, host-call qua SVC) + HLE WIPI-C. Rename/deobfuscate: **không áp dụng** (không có source Java; `binary.mod` giữ nguyên byte-by-byte, đã kiểm md5). Mapping rename: không có.
Bằng chứng ưu tiên: bytecode/mã ARM > log runtime > ảnh chụp.

## 3. Thay đổi so với engine HL5 (`hl5j` → `gcj`)
| # | Thay đổi | Lý do / bằng chứng |
|---|---|---|
| 1 | `LgtRuntime.HL5_PATCHES` (false) gác `Hl5Offline.install()` | nó `expect()` mã HL5 tại 0x4bdf0 → ném lỗi trên binary khác (đã gặp) |
| 2 | `LgtAot.java` sinh mới từ profile GrandChase (`gcj/profiles/gc_play1.txt`, 28 G lệnh), 213 vùng/756 entry, phủ 98,6% | profile: 5 hàm nóng (0x30d0 51%, 0x24d0 18%...) |
| 3 | `GameCanvas`: AID/PID mặc định, `HL5-BLIT` mặc định 0 | AID/PID đúng; blitter HL5 hook địa chỉ HL5 |
| 4 | `build.sh`/`makegc.sh`: tên GrandChase, vendor, chuyển âm thanh, icon từ `middle.png` | |
| 5 | `RunHeadless`: thêm `HL4_CALL` | gọi hàm khách để test lưu game |
| 6 | `gc/tools/j2me_scan.py` | quét tương thích (xem §4) |
| 7 | **r2:** thêm stdlib 0x415 = memmove (`Memory.copy` an toàn chồng lấn) | kiểm tra import tĩnh: thunk `.data` 0x14000f0 (gọi ở 0x38c3c, hàm 0x38c30 dịch byte `r1+2 ← r1`) chưa cài; log chạy chưa bao giờ chạm tới |
| 8 | **r2:** `HL4-FPS` mặc định 27 (trước 25) | timer game 36–40 ms ≈ 26,5 fps; 25 chậm hơn gốc ~6% trên máy nhanh |

## 4. Kiểm chứng đã thực hiện
- Chạy headless 300 s game (chuỗi phím giả ngẫu nhiên): logo Netmarble → tiêu đề → chọn nhân vật → intro → tàu bay → làng → đồng cỏ, không ngoại lệ, không `unimplemented`.
- **AOT bit-exact:** 200 s game, cùng chuỗi phím: thông dịch 18.311.896.852 lệnh, AOT 18.311.896.852 lệnh; thống kê svc y hệt; 20/20 ảnh trùng từng byte. Tốc độ: 66 → 639 MIPS (×9,6).
- Chạy lại bằng class trích từ jar cuối: cùng icount, ảnh trùng (class đã preverify).
- Quét `j2me_scan.py` trên jar: 36 class, mọi tham chiếu class/field/method đều có trong CLDC1.1+MIDP2.0 stub; class-file ≤ v49; không jsr/ret/invokedynamic; mọi method có nhánh đều có StackMap (preverify OK); không method ≥ 64 KB. (Kiểm tra phủ định: class SE chưa preverify bị báo VIOLATION classversion=65.)
- Lưu game: `HL4_CALL=150000:7b8c` → `Grand0.sav` (2258 B), `Grand5.sav` (2 B); khởi động lại: game mở lại cả hai file.
- Âm thanh: `HL4_SNDLOG` → `snd create/play /1.mid loop` (stub HL4SND phân giải đúng).
- MicroEmulator 2.0.4 (Xvfb, thiết bị 240x320): vỏ MIDP thật (`HL4Midlet`/`GameCanvas`) khởi động, vẽ màn "이용안내". (MicroEmulator mặc định nhỏ hơn 240x320 thì drawRGB của nó ném lỗi — hạn chế của emulator; game nhắm 240x320.) Lỗi âm thanh trong log chỉ vì Xvfb không có thiết bị audio.
- Binary diff jar gốc→mới: `binary.mod` giống hệt; 62 `.mmf` thay bằng stub; thêm 62 `.mid/.wav`, `SND/list.txt`, `icon.png`, 36 class `hl4/*`; không xoá file nào.
- Heap khách: peak ~285 KB, 48 trang × 64 KB = 3 MB bộ nhớ khách (bss 1,3 MB). Kích thước jar 3,6 MB. Không thêm cấp phát trong paint/vòng lặp so với engine HL5 (không sửa phần đó).

### Kiểm tra bổ sung (r2)
- **Import tĩnh:** quét thunk trong text + `.data`, chỉ tính cái được tham chiếu từ literal pool/veneer. Mọi WIPI-C (`0x1fb`) đều có `case`; stdlib dùng: memcpy 0x414, memset 0x418 (thunk text) và thunk `.data` 0x14000f0 = memmove 0x415 (đã thêm ở r2). `0x12c/0x12d` (gọi ở 0x38e84 lúc khởi động) = lấy số/danh sách tham số khởi chạy ("EN/S"…); trả 0 → game đi nhánh "không có tham số" (-1), đúng khi chạy không launcher.
- **Phím:** quét tĩnh các phép so sánh mã phím: -16 (CLR) 20 vị trí, -5 (OK) 54 vị trí, -7 (RSK) 1 vị trí, **không thấy -6 (LSK)** → ánh xạ LSK→CLR của vỏ MIDP không làm mất chức năng. (Thử động không kết luận được: màn thử đang ở đoạn hội thoại modal.)
- **Lưu game (vòng khép kín):** (a) trạng thái ở 150 s → `Grand0.sav` 2258 B md5 60a5348c…; (b) khởi động mới ở 30 s (state khác, save = 2141 B), nạp file (a) bằng hàm nạp 0x9b6c rồi lưu lại 0x7b8c → md5 y hệt 60a5348c… ⇒ nạp khôi phục đúng các trường được lưu. Lưu ghi thẳng `Grand%d.sav` (mode 4), không tạo `temp.sav`; hàm dọn 0x1b18 không được gọi trong luồng quan sát. Lưu qua menu UI của game **chưa** thử được (headless không tới được menu).
- **AOT vs thông dịch, seed khác** (`monkey:5`, 150 s): icount 14.003.466.423 trùng, 15/15 ảnh trùng.
- **Âm thanh 300 s:** chỉ tạo `/1 /2 /4 /8 /13 /14 .mid`, `/51 /52 /53 .wav`; không có `raw…`. `.ymp` (54 file) không thấy được tải khi chơi, không phải âm thanh.
- **Diff jar gốc→r2:** thay đổi 63 mục = 62 `.mmf` (→ stub) + `META-INF/MANIFEST.MF`.
- **fps:** harness (100 MIPS ảo): 4,5 triệu lệnh ARM/khung → ~22 khung/s do CPU, cap 25/27 không ảnh hưởng.
- Jar r2: quét sạch; class trích từ jar r2 cho icount và 20/20 ảnh trùng bản thông dịch.

## 5. NOT J2ME-SAFE / chưa kiểm được
- **Hiệu năng trên KVM thật:** ~4,5 triệu lệnh ARM mỗi khung (0x30d0 = blitter sprite 22 chế độ chiếm 51%, 0x24d0 18%). Trên KVM đời cũ sẽ rất chậm; hợp J2ME Loader/máy hiện đại. Hướng cải thiện: HLE blitter 0x30d0/0x24d0 bằng Java (như `Hl5Blit` của HL5) — chưa làm.
- **Chưa chạy trên KVM/thiết bị thật hoặc J2ME Loader** (chỉ MicroEmulator + harness) (không có trong sandbox). Cùng engine với HL5, nhưng GrandChase chưa được xác nhận trên máy thật.
- Bộ nhớ: bss 1,3 MB + hình ảnh/ARM trong Java int[] pages → cần máy ≥ ~6 MB heap JVM; `LgtAot` class 459 KB (có thể quá lớn cho KVM cũ; nếu lỗi, build không AOT bằng cách xoá `LgtAot.java` thay stub rỗng `FUNCMIN` cao hơn).
- Chưa chơi qua các chức năng sâu (chiến đấu, shop, thành tựu); chưa kiểm tra rung/âm thanh thật.
- `ZIM_LGT_20_ARM.lib`/`MLibID.sig` không được nạp; nếu một màn nào đó cần, sẽ có "unimplemented"/stub trong log.
- Chữ trong **ảnh** (logo, tiêu đề, nút đồ hoạ) vẫn tiếng Hàn/Anh gốc: chưa sửa ảnh.
- Heap thêm cho Việt hoá: `gcvi.bin` 292 KB (byte[] + bảng 4332×13 B) + font 2,7 KB + cache hình chữ nhật glyph (lười) ≈ 0,4 MB.

## 4b. Việt hoá r3
### Font 13px chân chọn lọc
- Nguyên nhân: bản nháp trước dùng font tạm do tôi tự sinh (khi chưa có bộ font) — người dùng phản hồi sai font.
- Sửa: dùng đúng `NAM_P/fonts/f13c.bin` (md5 fb9f3903…, 229 ký tự, cao 13, rộng 2–7, cách 3). Định dạng NAM.P (`writeUTF charset · height · width[] · atlas 1bpp LSB-first`) khớp `VnFont` sẵn có, không cần đổi mã đọc. Đường chân chữ (hàng 10) → `yOff = 9 − 10 = −1` so với chữ Hàn 11 hàng.
- Test: `trcheck.py` với f13c: 4332/4332 chuỗi, 0 ký tự ngoài font. Ảnh headless: menu, Hệ thống/Giới thiệu/Lưu ý/Thông tin, bảng nhân vật, trang bị, bản đồ, màn hướng dẫn đầu; MicroEmulator (vỏ MIDP thật) hiển thị màn hướng dẫn tiếng Việt từ jar r3.
### Thay chữ khi chạy
- Cách làm: hook 3 hàm chữ của game. `conv(0x375cc)` băm chuỗi EUC-KR gốc → tra `gcvi.bin` (khớp nguyên câu, hoặc ghép mảnh dài nhất) → ghi đơn vị 0xE000+chỉ số glyph; `measure`/`glyph` vẽ glyph f13c bằng fillRect của game (màu lấy từ màu chữ hiện tại). Không khớp → hàm gốc (chữ Hàn hiện như cũ).
- Ngắt dòng theo từ: game ngắt theo ký tự; trong conv, với 5 điểm gọi nhiều dòng (LR 0x386dc/0x3898c → rộng [sp+0x2c], 0x387c8/0x388ea → [sp+0x30], 0x35380 hội thoại chữ chạy → short@0x162a0b0 − 0x37) thay dấu cách cuối vừa dòng bằng mã xuống dòng của chỗ gọi (`|` hoặc `/`). Kiểm từ disasm 0x386c4: game vẽ ký tự rồi mới so `xoff > rộng`, nên ngắt theo từ của ta không bao giờ vượt chỗ game tự ngắt.
- Bộ nhớ (yêu cầu strict): bỏ mọi cấp phát mỗi khung: từ điển giải mã vào `char[]` dùng lại (không tạo `String`), mảng tham số `cpu.call` dùng lại, `Cpu.call` lấy mảng lưu thanh ghi từ pool theo độ sâu (trước đây `new int[16]` mỗi lần, mỗi glyph gọi fillRect nhiều lần).
### Kiểm chứng r3
- AOT vs thông dịch (`monkey:11`, 70 s): dòng svc trùng, 7/7 ảnh trùng md5; class trích từ jar r3 cho cùng kết quả. Sau khi bỏ cấp phát: 7/7 + 50/50 ảnh trùng bản trước (không đổi hành vi).
- `j2me_scan.py` jar r3: 38 class, 0 vi phạm, mọi method có nhánh đều có StackMap; class v46.
- Diff jar r2 → r3: thêm `GcText/GcDict.class`, `vi/font.bin`, `vi/gcvi.bin`; đổi `LgtAot`, `Cpu`, `VnFont`, `LgtRuntime`, `GameCanvas`; `binary.mod` và tài nguyên game không đổi.

## 4c. r4: chữ Hàn còn sót, cash shop offline
### Chữ Hàn còn sót (tên item/địa điểm trong câu ghép, nhãn NPC bị cắt)
- Nguyên nhân: tên item/địa điểm có trong từ điển nhưng chỉ khớp nguyên câu; câu ghép như "HP포션(소) × 5", "장소: 세르딘성 광장", "작은 사탕 획득" thì không khớp. Nhãn NPC tính khung bằng `strlen/2 × 11` px của chuỗi Hàn gốc nên bản dịch dài bị cắt.
- Sửa: `extract.py` đọc đúng bảng item của ConstData (bản ghi: tên u16@+2, độ dài @+4; mô tả @+5/+7; gốc/kích thước bản ghi lấy từ các constructor 0x51d0…0x5a30), và đánh dấu tên ngắn (const/map/npc/mix/quest, 4–24 byte) là mảnh (F). HLE `strlen`: tại 11 điểm tính khung (LR 0xf0d4…0x36c22) trả "độ dài ảo" = 2·⌈rộng_VN/11⌉. "0thư mới" sửa thành " thư mới".
- Test: bảng nhiệm vụ trong save của người dùng ("Mảnh bình cổ [0 \ 1]", "Nơi: Ngoại ô Serdin 1"); nhãn "Thương nhân đặc biệt" vừa khung; 3 lượt monkey × 240 s với `-Dgclog=1`: không còn khoá Hàn nào chưa dịch (chỉ số/ASCII).
### Cash shop / mua miễn phí
- Phân tích: menu Mạng (`menu.tx` dòng 43 có "캐쉬 상점") bị gán cứng 2 mục ở 0x3ad48, bộ điều phối trạng thái 0x3f630 không có trạng thái 5 ⇒ bản LGT này đã bỏ cash shop. Nội dung trả phí còn lại: chìa khoá rương (rusty/iron/gold 500/900/1300 won, 0x1d1b0) và bùa hồi sinh (100 won, 0x13d36), cùng đi qua lệnh mạng 0x65.
- Sửa (chỉ Java, không vá ARM, AOT không đổi): `GcServer` (cổng 10022) thay server thật: đăng nhập 0x191, thông báo 0x2bd; 0x65 luôn thành công (0x66 payload[2]=0 ⇒ game tự quay đồ trong rương bằng 0x8e88; hồi sinh 0x13ebc không đọc payload). "Mua vật phẩm" của sàn đấu giá thành cửa hàng: tìm 0x1f5/0x1fb → 0x1f6 (n × header 12 byte `[u32 mã niêm yết][u16 id][u16 số lượng][u32 giá=0]` + thân item theo loại) dựng bằng chính constructor của game vào vùng nhớ tạm; mua 0x1f7 → chép đúng thân đã hiển thị vào ô trống đầu tiên (như handler nhận thư 0x130) + 0x7d9c, trả 0x1f8 ⇒ game trừ 0 GP và tự lưu (0x7b8c). Túi đầy ⇒ báo "인벤토리가 부족합니다." (đã dịch). Bán 0x1f9: game đã gỡ item trước khi gửi ⇒ server trả lại thân item (payload+0x34) rồi từ chối. Lệnh khác: từ chối với thông báo offline (mục quản lý dữ liệu đẩy save lên server không có trong bản này).
- Test: mua 2 món → túi ô 5/6 đúng thân, GP giữ nguyên, save lớn thêm 46 byte; khởi động lại từ save đó: item còn; phân trang 0→0x168 qua ~490 item; bán: item trả lại nguyên thân, hiện thông báo; mở rương ép bằng `HL4_CALL` (0x21444 + 0x213ec(0x65)): thêm 1 vật phẩm mới; AOT vs thông dịch trên kịch bản mua: svc, 13/13 ảnh và file save trùng md5; class trích từ jar r4 cho kết quả trùng.
- Chưa kiểm: mở rương thật trên bản đồ (headless chưa tới rương), hồi sinh trả phí khi chết, máy thật/J2ME Loader.

## 6. Lệnh tái lập
Xem README-GC.md.

## 7. Việc tồn đọng
1) Người dùng thử trên máy/emulator thật, báo lỗi; 2) profile thêm lúc chiến đấu để mở rộng AOT; 3) Việt hoá chữ trong ảnh (tiêu đề, nút); 4) soát thêm bố cục ở màn chiến đấu/shop sâu.
