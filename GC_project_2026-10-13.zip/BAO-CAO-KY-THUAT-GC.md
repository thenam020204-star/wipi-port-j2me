# Báo cáo kỹ thuật: GrandChase LGT → J2ME (r1)

## 1. Kiểm kê
`0002D176.jar` 2,86 MB, 952 file: `binary.mod` (ELF ARM, .text 0x1000+0x432a8, .data 0x1400000+0x470, .bss 0x1500000+0x13dca8, `.raptor`), 62 `.mmf`, 271 `.pbp`, 239 `.msd`, 106 `.mgd`, 91 `.scp`, 90 `.dat`, 54 `.ymp`, 27 `.pal`, `GrandChase.xrf`, `ConstData.br`, `Font.br`, `icon.br`, `Xfont.dt`, `GET.dt`, `menu.tx`, `npcmenu.tx`, `MLibID.sig`, `ZIM_LGT_20_ARM.lib`. `app_info`: PID PD138681, WIPIVer 1, MClass Clet, MaxThread 3. Mục tiêu CLDC1.1/MIDP2.0 (stub jar kèm `tools/`).
Entry: `CletRegister start=0x1069 paint=0x1135 event=0x1089`.

## 2. Phương pháp
Không viết lại logic; chạy ARM gốc (Cpu ARMv5TE, host-call qua SVC) + HLE WIPI-C. Rename/deobfuscate: **không áp dụng** (không có source Java; `binary.mod` giữ nguyên byte-by-byte, đã kiểm md5). Mapping rename: không có.
Bằng chứng ưu tiên: bytecode/mã ARM > log runtime > ảnh chụp.

## 3. Thay đổi so với engine HL5 (`hl5j` → `gcj`)
| # | Thay đổi | Lý do / bằng chứng |
|---|---|---|
| 1 | `LgtRuntime.HL5_PATCHES` (false) gác `Hl5Offline.install()` | nó `expect()` mã HL5 tại 0x4bdf0 → ném lỗi trên binary khác (đã gặp) |
| 2 | `LgtAot.java` sinh mới từ profile GrandChase (`gcj/profiles/gc_play1.txt`, 28 G lệnh), 213 vùng/756 entry, phủ 98,6% | profile: 5 hàm nóng (0x30d0 51%, 0x24d0 18%...) |
| 3 | `GameCanvas`: AID/PID mặc định, `HL5-BLIT` mặc định 0 | AID/PID đúng; blitter HL5 hook địa chỉ HL5 |
| 4 | `build.sh`/`makegc.sh`: tên GrandChase, vendor, chuyển âm thanh, icon từ `middle.png` | |
| 5 | `RunHeadless`: thêm `HL4_CALL` | gọi hàm khách để test lưu game |
| 6 | `gc/tools/j2me_scan.py` | quét tương thích (xem §5) |

## 4. Kiểm chứng đã thực hiện
- Chạy headless 300 s game (chuỗi phím giả ngẫu nhiên): logo Netmarble → tiêu đề → chọn nhân vật → intro → tàu bay → làng → đồng cỏ, không ngoại lệ, không `unimplemented`.
- **AOT bit-exact:** 200 s game, cùng chuỗi phím: thông dịch 18.311.896.852 lệnh, AOT 18.311.896.852 lệnh; thống kê svc y hệt; 20/20 ảnh trùng từng byte. Tốc độ: 66 → 639 MIPS (×9,6).
- Chạy lại bằng class trích từ jar cuối: cùng icount, ảnh trùng (class đã preverify).
- Quét `j2me_scan.py` trên jar: 36 class, mọi tham chiếu class/field/method đều có trong CLDC1.1+MIDP2.0 stub; class-file ≤ v49; không jsr/ret/invokedynamic; mọi method có nhánh đều có StackMap (preverify OK); không method ≥ 64 KB. (Kiểm tra phủ định: class SE chưa preverify bị báo VIOLATION classversion=65.)
- Lưu game: `HL4_CALL=150000:7b8c` → `Grand0.sav` (2258 B), `Grand5.sav` (2 B); khởi động lại: game mở lại cả hai file.
- Âm thanh: `HL4_SNDLOG` → `snd create/play /1.mid loop` (stub HL4SND phân giải đúng).
- MicroEmulator 2.0.4 (Xvfb, thiết bị 240x320): vỏ MIDP thật (`HL4Midlet`/`GameCanvas`) khởi động, vẽ màn "이용안내". (MicroEmulator mặc định nhỏ hơn 240x320 thì drawRGB của nó ném lỗi — hạn chế của emulator; game nhắm 240x320.) Lỗi âm thanh trong log chỉ vì Xvfb không có thiết bị audio.
- Binary diff jar gốc→mới: `binary.mod` giống hệt; 62 `.mmf` thay bằng stub; thêm 62 `.mid/.wav`, `SND/list.txt`, `icon.png`, 36 class `hl4/*`; không xoá file nào.
- Heap khách: peak ~285 KB, 48 trang × 64 KB = 3 MB bộ nhớ khách (bss 1,3 MB). Kích thước jar 3,6 MB. Không thêm cấp phát trong paint/vòng lặp so với engine HL5 (không sửa phần đó).

## 5. NOT J2ME-SAFE / chưa kiểm được
- **Chưa chạy trên KVM/thiết bị thật hoặc J2ME Loader** (không có trong sandbox). Cùng engine với HL5, nhưng GrandChase chưa được xác nhận trên máy thật.
- Bộ nhớ: bss 1,3 MB + hình ảnh/ARM trong Java int[] pages → cần máy ≥ ~6 MB heap JVM; `LgtAot` class 459 KB (có thể quá lớn cho KVM cũ; nếu lỗi, build không AOT bằng cách xoá `LgtAot.java` thay stub rỗng `FUNCMIN` cao hơn).
- Chưa chơi qua các chức năng sâu (chiến đấu, shop, thành tựu); chưa kiểm tra rung/âm thanh thật.
- `ZIM_LGT_20_ARM.lib`/`MLibID.sig` không được nạp; nếu một màn nào đó cần, sẽ có "unimplemented"/stub trong log.
- Chữ Hàn chưa Việt hoá.

## 6. Lệnh tái lập
Xem README-GC.md.

## 7. Việc tồn đọng
1) Người dùng thử trên máy/emulator thật, báo lỗi; 2) profile thêm lúc chiến đấu để mở rộng AOT; 3) Việt hoá nếu cần.
