# GrandChase (그랜드체이스, Netmarble/KOG, LGT WIPI, AID 0002D176) → J2ME

Bản chuẩn: `release/GC_LGT_r2.jar/.jad` (MIDP2.0/CLDC1.1, 240x320, chạy nguyên `binary.mod` ARM gốc trong trình thông dịch Java + AOT, HLE WIPI-C).
Nhánh engine `gcj/` = bản sao `hl5j` (LGT mới nhất), **không đụng `hl4j/`, `hl5j/`**.

## Dựng lại (cần `/home/claude/work`, JDK11+, python3, `pip install capstone`)
```
unzip gói -> /home/claude/work ; cp GC.zip (zip gốc: jar+app_info) ; ./makegc.sh _r2   # -> distgc/GC_LGT_r2.jar/.jad
python3 gc/tools/j2me_scan.py distgc/GC_LGT_r2.jar tools/cldc-1.1-stub-1.0.jar tools/midp-2.0-stub-1.0.jar   # quét tương thích J2ME
gcj/tools/regen_aot.sh      # sinh lại LgtAot.java từ gcj/profiles/gc_*.txt
```
Chạy headless: `S=/tmp/x HL4_NOBLIT=1 HL4_AOT=1 CP=gcj/build/t gcj/tools/run.sh <tên> <ms> <chu kỳ> "<phím>" [storage]` (cần `HL4_NOBLIT=1`: blitter HL5 không dùng cho game này). Gọi hàm khách: `HL4_CALL="150000:7b8c"` (lưu game ở 0x7b8c). Phím: UP DOWN LEFT RIGHT OK LSK RSK CLR 0-9.
Tra mã: `python3 gc/tools/img.py dis <từ> <đến>` / `str` / `xref`.

## Khác HL5
- Tài nguyên phẳng ở gốc jar (không có `res/`): `LgtRuntime.resource()` đã thử cả hai đường dẫn nên không cần sửa.
- `LgtRuntime.HL5_PATCHES=false` (mặc định): bỏ vá offline/menu dành riêng HL5 (địa chỉ 0x4bdf0...). Không có blitter HLE (`HL5-BLIT: 0` mặc định trong `GameCanvas`).
- AID/PID mặc định `0002D176`/`PD138681`. Game dùng API: GetResource, grp*, db (Grand%d.sav, 0x190-0x1a0), mda clip, timer. **Không dùng mạng** (không có chuỗi URL/socket; chuỗi duy nhất: help@moazio.com). `ZIM_LGT_20_ARM.lib`/`MLibID.sig` không được game nạp (không có import tương ứng) — giữ nguyên trong jar.
- Âm thanh: 62 SMAF → 23 `.mid` + 39 `.wav` (SndConvert5, `SND/list.txt`), stub `HL4SND` thay file gốc.
- Phím: LSK → CLR (menu), như HL4/HL5. `HL4-FPS: 27`.

## Lưu game
`Grand%d.sav` (0..5) + `Grand5.sav` (2 byte, chỉ mục). Hàm lưu 0x7b8c, đọc ~0x1b90. Đã kiểm: gọi 0x7b8c → tạo `Grand0.sav` 2258 B + `Grand5.sav`; khởi động lại thấy game đọc lại cả hai.

## Việc tồn đọng
Xem BAO-CAO-KY-THUAT.md §7. Việt hoá chưa làm (chữ Hàn trong `GrandChase.xrf`, `*.scp`, `*.dat`, ảnh): làm theo skill j2me-viet-hoa nếu cần.
