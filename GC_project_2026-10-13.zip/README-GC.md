# GrandChase (그랜드체이스, Netmarble/KOG, LGT WIPI, AID 0002D176) → J2ME

Bản chuẩn: `release/GC_LGT_r3.zip` (jar+jad, **Việt hoá 100%**, font 13px chân chọn lọc `f13c` của bộ NAM.P) (MIDP2.0/CLDC1.1, 240x320, chạy nguyên `binary.mod` ARM gốc trong trình thông dịch Java + AOT, HLE WIPI-C).
Nhánh engine `gcj/` = bản sao `hl5j` (LGT mới nhất), **không đụng `hl4j/`, `hl5j/`**.

## Dựng lại (cần `/home/claude/work`, JDK11+, python3, `pip install capstone`)
```
unzip gói -> /home/claude/work ; cp GC.zip (zip gốc: jar+app_info) ; gc/tools/mkvi.sh   # gc/extra/vi/{font.bin,gcvi.bin}
./makegc.sh _r3   # -> distgc/GC_LGT_r3.jar/.jad
python3 gc/tools/j2me_scan.py distgc/GC_LGT_r3.jar tools/cldc-1.1-stub-1.0.jar tools/midp-2.0-stub-1.0.jar   # quét tương thích J2ME
gcj/tools/regen_aot.sh      # sinh lại LgtAot.java từ gcj/profiles/gc_*.txt
```
Chạy headless: `S=/tmp/x HL4_NOBLIT=1 HL4_AOT=1 CP=gcj/build/t gcj/tools/run.sh <tên> <ms> <chu kỳ> "<phím>" [storage]` (cần `HL4_NOBLIT=1`: blitter HL5 không dùng cho game này). Gọi hàm khách: `HL4_CALL="150000:7b8c"` (lưu game ở 0x7b8c). Phím: UP DOWN LEFT RIGHT OK LSK RSK CLR 0-9.
Tra mã: `python3 gc/tools/img.py dis <từ> <đến>` / `str` / `xref`.

## Khác HL5
- Tài nguyên phẳng ở gốc jar (không có `res/`): `LgtRuntime.resource()` đã thử cả hai đường dẫn nên không cần sửa.
- `LgtRuntime.HL5_PATCHES=false` (mặc định): bỏ vá offline/menu dành riêng HL5 (địa chỉ 0x4bdf0...). Không có blitter HLE (`HL5-BLIT: 0` mặc định trong `GameCanvas`).
- AID/PID mặc định `0002D176`/`PD138681`. Game dùng API: GetResource, grp*, db (Grand%d.sav, 0x190-0x1a0), mda clip, timer. **Không dùng mạng** (không có chuỗi URL/socket; chuỗi duy nhất: help@moazio.com). `ZIM_LGT_20_ARM.lib`/`MLibID.sig` không được game nạp (không có import tương ứng) — giữ nguyên trong jar.
- Âm thanh: 62 SMAF → 23 `.mid` + 39 `.wav` (SndConvert5, `SND/list.txt`), stub `HL4SND` thay file gốc.
- Phím: LSK → CLR (menu), như HL4/HL5. `HL4-FPS: 27`.

## Lưu game
`Grand%d.sav` (0..5) + `Grand5.sav` (2 byte, chỉ mục). Hàm lưu 0x7b8c, đọc ~0x1b90. Đã kiểm: gọi 0x7b8c → tạo `Grand0.sav` 2258 B + `Grand5.sav`; khởi động lại thấy game đọc lại cả hai.

## Việt hoá (r3)
- Trích: `gc/tools/extract.py` → `gc/vi/ex/catalog.tsv` (4332 chuỗi: m*/n*, tips/scp, menu.tx/npcmenu.tx, ConstData, literal trong binary). Id giữ cố định giữa các lần trích.
- Dịch: `gc/vi/tr/*.tsv` (`id<TAB>tiếng Việt`; giữ `@d` màu và `|` xuống dòng, không dùng `/`), thuật ngữ `gc/vi/tr/GLOSSARY.md`. Kiểm: `python3 gc/tools/trcheck.py gc/vi/font/font13c.bin` (id, `@`, ký tự ngoài font, độ phủ).
- Gói: `gc/tools/mkvi.sh` → `font.bin` (= `NAM_P/fonts/f13c.bin`, xem `gc/vi/font/NGUON.txt`) + `gcvi.bin` (từ điển băm FNV-1a theo byte EUC-KR gốc).
- Engine: `gcj/src/core/hl4/lgt/GcText.java` (hook conv 0x375cc / measure 0x379d0 / glyph 0x37ee8, ngắt dòng theo từ), `GcDict.java`. AOT loại trừ 0x35358–0x38b94.
- Đổi font: thay `gc/vi/font/font13c.bin` (cùng định dạng NAM.P), chạy `trcheck.py`, `mkvi.sh`, `makegc.sh`.
- Headless có chữ Việt: `VI=gc/extra/vi AOT=1 gc/tools/r.sh <tên> <ms> <chu kỳ> "<phím>" [storage]` (mặc định CP=gcj/build/test, nhớ `gcj/tbuild.sh` sau khi sửa Java).

## Việc tồn đọng
Xem BAO-CAO-KY-THUAT-GC.md §7: chữ Hàn trong ảnh (tiêu đề/nút) chưa Việt hoá; chưa thử máy thật/J2ME Loader.
