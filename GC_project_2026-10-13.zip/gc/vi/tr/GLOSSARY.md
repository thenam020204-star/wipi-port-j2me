# Hướng dẫn dịch GrandChase Hàn -> Việt (game J2ME, màn hình 240x320, font 13px)
Định dạng file dịch: mỗi dòng `id<TAB>bản dịch` (UTF-8). Chỉ chứa id có trong batch. Không dòng trống/nhận xét.

## Quy tắc kỹ thuật (BẮT BUỘC)
- Giữ nguyên mã màu `@` + chữ số (vd `@3`, `@9`), đúng thứ tự/số lượng như bản Hàn.
- Giữ nguyên `|` (xuống dòng cưỡng bức) nếu bản Hàn có; không tự thêm `|`. TUYỆT ĐỐI không dùng `/` (là ký tự ngắt dòng của game) -> dùng "hoặc", "và", "-".
- Không dùng tab, xuống dòng thật. Không dấu ngoặc kép "..." kiểu thông minh; dùng "..." thường được.
- Câu thoại tự xuống dòng theo chiều rộng; hộp thoại chỉ 2 dòng/trang nên DỊCH NGẮN GỌN, súc tích (tiếng Việt thường dài hơn Hàn ~1.5x; đừng thêm ý, bỏ từ thừa). Một chuỗi tương ứng một câu thoại: không gộp/tách.
- Phần trong `[ ... ]` là tên vật phẩm: dịch theo bảng thuật ngữ dưới (nhất quán).
- Chuỗi chỉ gồm số/ký hiệu hoặc không cần dịch: chép lại nguyên.
- Dấu câu: giữ `?`, `!`, `...`, `..` như nguyên bản. Chỉ dùng chữ Latin tiếng Việt đủ dấu (Unicode dựng sẵn NFC), không emoji.

## Văn phong
Fantasy phiêu lưu, game hành động. Elesis (nữ kị sĩ trẻ, nói thẳng, hơi lạnh lùng với Kanavan): xưng "tôi/ta" tùy ngữ cảnh, gọi người lớn tuổi/cấp trên lịch sự. Nữ hoàng Serdin/Kanavan: xưng "ta", gọi "ngươi/khanh"; kị sĩ nói với nữ hoàng dùng "bệ hạ", "thần". NPC làng: thân mật, đời thường. Quái/boss: ngắn, hung hăng.
Hàn dùng lối nói trang trọng/thân mật khác nhau -> chọn tương đương Việt tự nhiên.

## Thuật ngữ (dùng đúng như sau)
Địa danh: 세르딘 Serdin; 카나반 Kanavan; 엘리아 Elia; 베르메시아 Bermesia; 가이코즈 Gaikoz; 고르고스 Gorgos; 망각의 늪 Đầm Lãng quên; 망자의 묘지 Nghĩa địa; 메마른 땅 Đất khô cằn; 불의 사원 Đền Lửa; 오크 사원 Đền Orc; 유적 마을 Làng Di tích; 시련의 숲/탑 Rừng/Tháp Thử thách; 엘프 마을 Làng Elf; 카미키 Kamiki; 카제아제 Kazeaze; 캐리 비치 Carry Beach; 헬 브릿지 Hell Bridge; 트롤 던전 Hầm Troll; 몬스터 원정대 Đội viễn chinh quái vật; 비공정 Khinh khí cầu; 붉은 기사단 Hồng Kị sĩ đoàn; 기사단장 Đoàn trưởng (Hồng Kị sĩ đoàn); 내무대신 Nội vụ đại thần; 그랜드체이스 Grand Chase.
Nhân vật: 엘리시스 Elesis; 아르메 Arme; 라스 Lass; 라이 Rai; 노아 Noah; 노커 Knocker; 데니스 Dennis; 데이오스 Deios; 레노 Leno; 레이나 Reina; 로스 Ross; 록산느 Roxanne; 루이스 아줌마 bà Louis; 리르 Lire; 리아나 Liana; 마르샤 Marsha; 마리아 Maria; 마린 Marin; 멜리사 Melissa; 바니 Barney; 바딜 Badil; 베스테르 Bester; 비키 Vicky; 빅터 Victor; 사라 Sarah; 샘 Sam; 세바스 Sebas; 스탠 Stan; 시글러스 Siglus; 써니 Sunny; 아이샤 Aisha; 아이언 Iron; 알루 Alu; 앤디 Andy; 엘피스 Elpis; 워울프 Werewolf; 윈디 Windy; 윌리엄 William; 조르딘 Jordin; 카린 Karin; 카본 Carbon; 카일 Kyle; 칼리 Kali; 켈소 Kelso; 코니 Connie; 코퍼 Copper; 퀴니 Quinny; 크리미 Creamy; 크리스 Chris; 크리온 Creon; 클라우디아 Claudia; 킹 King; 테드 Ted; 테리 Terry; 토니 Tony; 티아나 Tiana; 펠리스 Felis; 피터 Peter; 카미키 Kamiki; 카제아제 Kazeaze (진 카제아제 Jin Kazeaze); 오크로드 Orc Lord; 레드 고르고스 Red Gorgos; 바실리스크 Basilisk; 가도센 Gadosen; 가이코즈 Gaikoz.
Quái: 슬라임 Slime, 고블린 Goblin, 오크 Orc, 트롤 Troll, 해골 Bộ xương, 좀비 Zombie, 하피 Harpy, 몽반 Mongban, 엔몬 Enmon, 루나 Luna, 시트 Sit, 펌프킨 Pumpkin, 엔트 Ent, 리치 Lich, 골렘 Golem, 외눈거인 Người khổng lồ một mắt, 싸이클롭스 Cyclops, 닌코 Ninko, 페페 Pepe (tên riêng giữ nguyên).
Hệ thống: 퀘스트 Nhiệm vụ; 인벤토리 Hành trang; 창고 Kho; 조합 Chế tạo; 조합서 Công thức; 강화 Cường hóa; 강화석 Đá cường hóa; 소켓 Ổ khảm; 룬 Rune; 채광 Khai khoáng; 직업변환 Chuyển nghề; 귀환 Trở về; 펫 Thú cưng; 보스 Boss; 메달 Huy chương; 쿠폰 Coupon; 노멀/하드모드 Chế độ Thường/Khó; 마을 Làng; 던전 Hầm ngục; 경험치 EXP; 레벨 Cấp; 스킬 Kỹ năng; 텔레포트 Dịch chuyển; 기사 Hiệp sĩ (Knight); 스피어/창병 Thương sĩ; 세이버 Saber. HP, SP, GP, STR, DEX, VIT, LUK, ATT, DEF giữ nguyên.
Vật phẩm: xem các file t03_const_a.tsv (id 272-1083) và t04_scp.tsv trong cùng thư mục để dùng đúng tên đã dịch (ví dụ 항아리 조각 = Mảnh bình cổ, 빛의 오닉스 = Onyx Ánh sáng, 어둠의 오닉스 = Onyx Bóng tối, 부유석 = Đá bay, 마법 램프 = Đèn thần).
