import sys
def resplit(real, mine):
    ns=[i for i,c in enumerate(real) if c!=' ']
    flat=''.join(real[i] for i in ns)
    pieces=[p for p in mine.strip().split('/')]
    pos=0; cuts=[0]
    for p in pieces:
        q=p.replace(' ','')
        if flat[pos:pos+len(q)]!=q: raise Exception('mismatch at %d: %r vs %r'%(pos,q,flat[pos:pos+len(q)+6]))
        pos+=len(q)
        cuts.append(ns[pos-1]+1 if pos>0 else 0)
    if pos!=len(flat): raise Exception('short %d %d'%(pos,len(flat)))
    cuts[-1]=len(real)
    out=[real[a:b] for a,b in zip(cuts,cuts[1:])]
    return [x for x in out if x]
if __name__=='__main__':
    d=open('../../jar/ConstData.br','rb').read(); pool=d[33490:]
    for f,o,l in [('split_pets.txt',3353,326),('split_mon.txt',14240,1286)]:
        r=pool[o:o+l].decode('cp949'); out=resplit(r,open(f,encoding='utf8').read())
        assert ''.join(out)==r
        print(f,len(out),out[:12])
