#!/bin/bash
# r.sh name ms every "keys" [vi dir] [extra env...]  : headless run with defaults (interpreter unless AOT=1)
export CP=${CP:-gcj/build/test} S=/tmp/claude-0/gcrun HL4_NOBLIT=1 HL4_VENEER=400c0
[ -n "$AOT" ] && export HL4_AOT=1
[ -n "$VI" ] && export HL4_GCVI=$VI
cd /home/claude/work
gcj/tools/run.sh "$1" "$2" "$3" "$4" "${5:-}" "${6:-0}" "${7:-40}" 2>&1 | tail -1
grep -a "BKPT\|Exception\|fatal" $S/$1.log | head -3
