#!/bin/bash
# Tạo gói Việt hoá: gc/extra/vi/{font.bin,gcvi.bin}  (đưa vào jar qua makegc.sh)
set -e
W=/home/claude/work; mkdir -p $W/gc/extra/vi
cp $W/gc/vi/font/font13c.bin $W/gc/extra/vi/font.bin
python3 $W/gc/tools/mkdict.py $W/gc/extra/vi/gcvi.bin
rm -f $W/gc/extra/vi/gcvi.bin.tsv
ls -l $W/gc/extra/vi
