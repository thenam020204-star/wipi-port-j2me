#!/usr/bin/env python3
"""trcheck.py: kiểm tra bản dịch (id tồn tại, giữ @d, không có '/', ký tự ngoài font, thống kê phủ)"""
import glob,sys,os,re
H=os.path.join(os.path.dirname(__file__),'..','vi')
cat={}
for l in open(H+'/ex/catalog.tsv',encoding='utf8'):
    a=l.rstrip('\n').split('\t',3); cat[int(a[0])]=a
tr={}
for f in sorted(glob.glob(H+'/tr/t*.tsv')):
    for n,l in enumerate(open(f,encoding='utf8'),1):
        l=l.rstrip('\n')
        if not l.strip(): continue
        a=l.split('\t',1)
        if len(a)<2 or not a[0].isdigit() or int(a[0]) not in cat: print('BAD',f,n,l[:40]); continue
        tr[int(a[0])]=a[1]
font=None
if len(sys.argv)>1 and os.path.exists(sys.argv[1]):
    import struct
    d=open(sys.argv[1],'rb').read(); n=struct.unpack('>H',d[:2])[0]; font=set(d[2:2+n].decode('utf8'))
warn=0
for i,v in tr.items():
    k=cat[i][3].replace('\\n','\n').replace('\\t','\t').replace('\\\\','\\')
    if re.findall(r'@\d',k)!=re.findall(r'@\d',v): print('ESC',i,k[:30],'|',v[:40]); warn+=1
    if '/' in v and cat[i][2]!='menu.tx': print('SLASH',i,v[:40]); warn+=1
    if font:
        miss=set(c for c in v if c not in font and c not in '\n')
        if miss: print('FONT',i,''.join(miss),v[:30]); warn+=1
tot=sum(len(cat[i][3].encode('cp949','ignore')) for i in cat)
done=sum(len(cat[i][3].encode('cp949','ignore')) for i in tr)
print('translated',len(tr),'/',len(cat),'bytes %d/%d (%.1f%%)'%(done,tot,100.0*done/tot),'warn',warn)
