#!/usr/bin/env python3
"""mkdict.py out.bin : catalog.tsv + vi/tr/t*.tsv -> TSV tạm -> build_gcvi.py -> gcvi.bin"""
import glob,os,sys,subprocess
H=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','vi')
cat={}
for l in open(H+'/ex/catalog.tsv',encoding='utf8'):
    a=l.rstrip('\n').split('\t',3); cat[int(a[0])]=a
tr={}
for f in sorted(glob.glob(H+'/tr/t*.tsv')):
    for l in open(f,encoding='utf8'):
        l=l.rstrip('\n')
        if not l: continue
        a=l.split('\t',1)
        if len(a)==2 and a[0].isdigit() and int(a[0]) in cat: tr[int(a[0])]=a[1]
tmp=sys.argv[1]+'.tsv'
n=0
with open(tmp,'w',encoding='utf8') as o:
    for i,v in sorted(tr.items()):
        fl=cat[i][1]
        v=v.replace('\\','\\\\').replace('\t','\\t')
        o.write('%s\t%s%s\n'%(cat[i][3],v,'\tF' if fl=='F' else ''))
        n+=1
print(n,'entries')
subprocess.check_call([sys.executable,os.path.join(os.path.dirname(os.path.abspath(__file__)),'build_gcvi.py'),sys.argv[1],tmp])
