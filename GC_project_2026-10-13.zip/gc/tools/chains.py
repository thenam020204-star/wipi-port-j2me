# generic (off16,len8) tiling-chain finder for .scp index vs .dat pool
def find(s, N, minrows=3):
    """return set of (off,len) segments; chains where row k+1 off == row k off+len, fixed stride R,
    also name+desc pairs (off2=off+len, next row off=off2+len2)"""
    segs=set()
    n=len(s)
    for p in range(0,n-3):
        o=s[p]|(s[p+1]<<8); l=s[p+2]
        if l==0 or o+l>N: continue
        for R in range(3,40):
            k=0; q=p; exp=o+l; rows=[(o,l)]
            while q+R+3<=n:
                q+=R
                o2=s[q]|(s[q+1]<<8); l2=s[q+2]
                if o2==exp and l2>0 and o2+l2<=N: rows.append((o2,l2)); exp=o2+l2
                else: break
            if len(rows)>=minrows:
                segs.update(rows)
    return segs
def pairs(s, N, minrows=3):
    segs=set(); n=len(s)
    for p in range(0,n-6):
        o=s[p]|(s[p+1]<<8); l=s[p+2]; o2=s[p+3]|(s[p+4]<<8); l2=s[p+5]
        if l==0 or o2!=o+l or o2+l2>N: continue
        for R in range(6,48):
            rows=[(o,l,l2)]; q=p; exp=o2+l2
            while q+R+6<=n:
                q+=R
                a=s[q]|(s[q+1]<<8); b=s[q+2]; c=s[q+3]|(s[q+4]<<8); e=s[q+5]
                if a==exp and b>0 and c==a+b and a+b+e<=N: rows.append((a,b,e)); exp=c+e
                else: break
            if len(rows)>=minrows:
                for a,b,e in rows:
                    segs.add((a,b)); 
                    if e: segs.add((a+b,e))
    return segs
