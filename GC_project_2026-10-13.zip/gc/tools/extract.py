#!/usr/bin/env python3
"""Trích mọi chuỗi Hàn của GrandChase -> vi/ex/catalog.tsv  (id, flags, korean)"""
import re,glob,os,sys
sys.path.insert(0,os.path.dirname(__file__)); sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..','vi','ex'))
import chains, resplit
J=os.path.join(os.path.dirname(__file__),'..','jar')
HG=re.compile('[\uac00-\ud7a3]')
ent={}   # korean -> [flags, src]
def add(k,src,frag=False):
    k=k.strip('\x00')
    if not k or not HG.search(k): return
    e=ent.setdefault(k,['',src])
    if frag: e[0]='F'
# 1. m*/n*
for f in sorted(glob.glob(J+'/[mn][0-9]*.scp'), key=lambda x:(x[len(J)+1], int(re.sub(r'\D','',os.path.basename(x))))):
    b=f[:-4]; n=os.path.basename(b)
    s=open(f,'rb').read(); d=open(b+'.dat','rb').read()
    mask=bytearray(len(d))
    for m in re.finditer(rb'\x11.\x00\x00\x00.(..)(..)',s,re.S):
        o=int.from_bytes(m.group(1),'little'); l=int.from_bytes(m.group(2),'little')
        if l>0 and o+l<=len(d):
            try: t=d[o:o+l].decode('cp949')
            except: continue
            if all(c>=' ' for c in t): add(t,n); mask[o:o+l]=b'\1'*l
    i=0
    while i<len(d):
        if not mask[i]:
            j=i
            while j<len(d) and not mask[j]: j+=1
            try: t=d[i:j].decode('cp949')
            except: t=d[i:j].decode('cp949','ignore')
            for p in re.split(r'(퀘스트 완료|퀘스트 획득|"YES"|"NO"|END)',t):
                if p and p not in('"YES"','"NO"','END'): add(p,n+'.run',True)
            i=j
        else: i+=1
# 2. pools via chains
for nm in ['tips','scp_map','scp_mix','scp_npc','scp_quest']:
    s=open(J+'/%s.scp'%nm,'rb').read(); d=open(J+'/%s.dat'%nm,'rb').read()
    sg=chains.find(s,len(d))|chains.pairs(s,len(d))
    cov=bytearray(len(d))
    for o,l in sorted(sg):
        add(d[o:o+l].decode('cp949'),nm); cov[o:o+l]=b'\1'*l
    i=0
    while i<len(d):
        if not cov[i]:
            j=i
            while j<len(d) and not cov[j]: j+=1
            t=d[i:j].decode('cp949')
            if nm=='scp_map':
                for p in re.findall(r'.+? \d(?=|$)',t) or [t]: pass
                for p in re.split(r'(?<=\d)',t): add(p,nm,True)
            else: add(t,nm,True)
            i=j
        else:i+=1
# 3. menus
for nm in ['menu.tx','npcmenu.tx']:
    t=open(J+'/'+nm,'rb').read().decode('cp949')
    for p in re.split(r'[@/$\r\n]',t): add(p.strip('|'),nm,len(p.strip('|'))>=8)
# 4. ConstData
d=open(J+'/ConstData.br','rb').read(); pool=d[33490:]; N=len(pool)
cov=bytearray(N)
def cadd(o,l):
    if l>0 and o+l<=N and not any(cov[o:o+l]):
        add(pool[o:o+l].decode('cp949'),'const'); cov[o:o+l]=b'\1'*l
for r in range(278): cadd(int.from_bytes(d[2+r*22:4+r*22],'little'), d[4+r*22])
# item tables (constructors 0x5758/0x5838/0x58c0/0x5988/0x5a30): name u16@+2 len@+4, description u16@+5 len@+7 (types 13-15)
for base,sz,n,desc in [(0x17ce,17,9,0),(0x1867,11,23,0),(0x1964,16,32,1),(0x1b64,14,85,1),(0x200a,13,66,1)]:
    for r in range(n):
        q=base+r*sz
        o=int.from_bytes(d[q+2:q+4],'little'); l=d[q+4]
        if l and o+l<=N: add(pool[o:o+l].decode('cp949'),'const')
        if desc:
            o=int.from_bytes(d[q+5:q+7],'little'); l=d[q+7]
            if l and o+l<=N: add(pool[o:o+l].decode('cp949'),'const')
pr={}
for p in range(6000,33490-12):
    o=int.from_bytes(d[p:p+2],'little'); l=d[p+2]
    if l<1 or o+l>=N: continue
    if int.from_bytes(d[p+3:p+5],'little')!=o+l: continue
    pr[p]=(o,l,d[p+5])
fnd=set()
for p,(o,l,l2) in pr.items():
    for R in range(6,48):
        q=p+R
        if q in pr and pr[q][0]==o+l+l2: fnd.add(p); fnd.add(q)
for p in sorted(fnd):
    o,l,l2=pr[p]; cadd(o,l); cadd(o+l,l2)
for f,o,l in [('split_pets.txt',3353,326),('split_mon.txt',14240,1286)]:
    r=pool[o:o+l].decode('cp949')
    for p in resplit.resplit(r,open(os.path.join(J,'..','vi','ex',f),encoding='utf8').read()): add(p,'const',True)
    cov[o:o+l]=b'\1'*l
unc=[(i,) for i in range(N) if not cov[i]]
print('const uncovered bytes',len(unc),file=sys.stderr)
# 5. binary literals
sys.path.insert(0,os.path.join(os.path.dirname(__file__)))
import img
a0,blob=img.text_bytes()
for m in re.finditer(rb'(?<=\x00)(?:[\x20-\x7e]|[\xb0-\xc8][\xa1-\xfe])+(?=\x00)',blob):
    try: t=m.group().decode('cp949')
    except: continue
    if sum('\uac00'<=c<='\ud7a3' for c in t)<2: continue
    if a0+m.start()<0x41400 or a0+m.start()>0x44200: continue
    t=t.replace('%%','%')
    for p in re.split(r'%[-0-9]*[sdxc]|\|+|\\',t):
        p=p.strip()
        if p: add(p,'bin',True)
# names also appear inside composed strings ("%s x 5", "<item> 획득", "장소 : <map>"): fragments
for k,e in ent.items():
    if re.sub(r'\d+','',e[1]) in ('const','scp_map','scp_mix','scp_npc','scp_quest') and 4<=len(k.encode('cp949'))<=24 and sum('\uac00'<=c<='\ud7a3' for c in k)>=2:
        e[0]='F'
CAT=os.path.join(os.path.dirname(__file__),'..','vi','ex','catalog.tsv')
old={}
if os.path.exists(CAT):
    for l in open(CAT,encoding='utf8'):
        a=l.rstrip('\n').split('\t',3)
        old[a[3]]=int(a[0])
nxt=max(old.values())+1 if old else 1
for k in '예 펫 룬 등 검 창 손 발 가'.split(): add(k,'bin1')   # 1-syllable literals
add('오프라인 버전에서는 지원하지 않는 기능입니다.','srv')   # GcServer (offline server) message
rows=sorted(ent.items(), key=lambda kv:(kv[1][1],kv[0]))
recs=[]
for k,(fl,src) in rows:
    ek=k.replace('\\','\\\\').replace('\t','\\t').replace('\n','\\n')
    if ek in old: i=old[ek]
    else: i=nxt; nxt+=1
    recs.append((i,fl,src,ek))
recs.sort()
out=open(CAT,'w',encoding='utf8')
for r in recs: out.write('%d\t%s\t%s\t%s\n'%r)
out.close()
tb=sum(len(k.encode('cp949')) for k in ent)
print(len(ent),'entries',tb,'bytes',file=sys.stderr)
from collections import Counter
c=Counter(); 
for k,(fl,src) in ent.items(): c[re.sub(r'\d+','#',src)]+=len(k.encode('cp949'))
print(c,file=sys.stderr)
