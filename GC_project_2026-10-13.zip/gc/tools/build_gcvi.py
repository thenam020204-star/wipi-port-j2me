#!/usr/bin/env python3
"""GrandChase dictionary builder.  build_gcvi.py <out gcvi.bin> <tsv>...
TSV: korean<TAB>vietnamese[<TAB>F]   (F = fragment: also replaced inside longer strings). '#' lines ignored.
Escapes in both columns: \\n newline, \\t tab, \\\\ backslash.  Key = EUC-KR (cp949) bytes of the Korean text."""
import struct, sys

def fnv(b):
    h = 0x811C9DC5
    for x in b:
        h = ((h ^ x) * 0x01000193) & 0xFFFFFFFF
    return h

def unesc(s):
    out = []; i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            n = s[i + 1]; i += 2
            out.append({'n': '\n', 't': '\t', '\\': '\\'}.get(n, '\\' + n)); continue
        out.append(c); i += 1
    return ''.join(out)

def load(files):
    ent = {}
    for f in files:
        for ln, line in enumerate(open(f, encoding='utf-8'), 1):
            line = line.rstrip('\n').rstrip('\r')
            if not line or line.startswith('#'): continue
            p = line.split('\t')
            if len(p) < 2 or not p[1].strip(): continue
            ko, vi = unesc(p[0]), unesc(p[1])
            fl = 1 if len(p) > 2 and p[2].strip().upper() == 'F' else 0
            try: kb = ko.encode('cp949')
            except UnicodeEncodeError: print('skip (not cp949):', f, ln, ko[:30], file=sys.stderr); continue
            ent[kb] = (vi, fl)
    return ent

def main():
    out = sys.argv[1]; ent = load(sys.argv[2:])
    rows = []; blob = bytearray(); off = {}
    for kb, (vi, fl) in ent.items():
        u = vi.encode('utf-8')
        if u not in off:
            off[u] = len(blob); blob += struct.pack('>H', len(u)) + u
        rows.append((fnv(kb), len(kb), fl, off[u], kb))
    rows.sort(key=lambda r: (r[0], r[1]))
    seen = {}
    for r in rows:
        k = (r[0], r[1])
        if k in seen and seen[k] != r[4]: print('HASH COLLISION', r[4], seen[k], file=sys.stderr); sys.exit(1)
        seen[k] = r[4]
    d = bytearray(struct.pack('>II', 0x47435631, len(rows)))
    for h, kl, fl, vo, kb in rows: d += struct.pack('>IHBI', h, kl, fl, vo)
    d += struct.pack('>I', len(blob)) + blob
    open(out, 'wb').write(d)
    print('entries', len(rows), 'fragments', sum(r[2] for r in rows), 'blob', len(blob), 'file', len(d))

if __name__ == '__main__': main()
