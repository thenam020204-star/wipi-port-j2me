#!/bin/bash
# Regenerate src/aot/hl4/aot/LgtAot.java (GrandChase) from stored profiles (absolute addresses).
cd "$(dirname "$0")/.."
P=profiles
python3 tools/aotgen.py --bin ../gc/jar/binary.mod --fileoff 0x34 --size 0x432a8 --base 0x1000 --class LgtAot \
  --out src/aot/hl4/aot/LgtAot.java --maxinsns 1000 --coldcut 0.001 --funcregions --hostcalls --funcmaxinsns 700 --maxbytes 7200 --funcmin ${FUNCMIN:-20000} --maxregions 4000 $EXTRA $P/gc_*.txt
