package hl4.lgt;

/**
 * Offline replacement of the GrandChase network server (TCP 10022).
 * <pre>
 *   request : u16 LE payload length, u16 LE command, payload
 *   reply   : u16 LE length (= 1 + payload), u16 LE command (= request + 1), u8 result, payload
 *             result 0 = ok; other results carry u16 LE length + EUC-KR message (shown by the game, 0x21012)
 * </pre>
 * Reply dispatcher 0x20640, request builder 0x1febc (command in [0x163683c]).
 * <ul>
 * <li>0x191 login, 0x2bd notices: accepted (empty notice list).</li>
 * <li>0x65 paid item (chest keys, revive scroll): always succeeds, free.</li>
 * <li>Trade "buy" (0x1f5 search / 0x1fb name search, 0x1f7 buy) works as a free shop over the game's own item
 *     tables: every item of the requested type/grade/level at 0 GP; the bought item (the exact body shown) goes
 *     straight into the first free bag slot.</li>
 * <li>Everything that would hand data or items to the server (sell, mail, server save upload, ranking...) is
 *     refused with an "offline" message, so nothing is lost.</li>
 * </ul>
 */
public class GcServer extends Hl5Server {
    private byte[] in = new byte[0];
    private byte[] out = new byte[0];

    GcServer(LgtRuntime rt) {
        super(rt);
    }

    public boolean acceptsPort(int port) {
        return port == 10022;
    }

    public void reset() {
        super.reset();
        in = new byte[0];
        out = new byte[0];
    }

    /** one reply per read: the game expects exactly one packet per buffer */
    public byte[] poll() {
        if (out.length < 4) {
            byte[] r = out;
            out = new byte[0];
            return r;
        }
        int len = (out[0] & 0xFF) | ((out[1] & 0xFF) << 8);
        int n = Math.min(out.length, len + 4);
        byte[] a = new byte[n], b = new byte[out.length - n];
        System.arraycopy(out, 0, a, 0, n);
        System.arraycopy(out, n, b, 0, b.length);
        out = b;
        return a;
    }

    public void receive(byte[] d) {
        in = cat(in, d);
        while (in.length >= 4) {
            int len = (in[0] & 0xFF) | ((in[1] & 0xFF) << 8);
            if (in.length < len + 4) return;
            int cmd = (in[2] & 0xFF) | ((in[3] & 0xFF) << 8);
            byte[] pl = new byte[len];
            System.arraycopy(in, 4, pl, 0, len);
            byte[] rest = new byte[in.length - len - 4];
            System.arraycopy(in, len + 4, rest, 0, rest.length);
            in = rest;
            request(cmd, pl);
        }
    }

    void reply(int cmd, int result, byte[] payload) {
        int n = 1 + payload.length;
        byte[] r = new byte[4 + n];
        r[0] = (byte) n;
        r[1] = (byte) (n >> 8);
        r[2] = (byte) cmd;
        r[3] = (byte) (cmd >> 8);
        r[4] = (byte) result;
        System.arraycopy(payload, 0, r, 5, payload.length);
        if (LOG) rt.log("[GcServer] reply " + Integer.toHexString(cmd) + " " + hexdump(r));
        out = cat(out, r);
    }

    /** error reply with a message (EUC-KR; translated on screen by GcText) */
    void refuse(int cmd, byte[] msg) {
        byte[] p = new byte[2 + msg.length];
        p[0] = (byte) msg.length;
        p[1] = (byte) (msg.length >> 8);
        System.arraycopy(msg, 0, p, 2, msg.length);
        reply(cmd, 1, p);
    }

    static final boolean LOG = System.getProperty("gcsrv.log") != null;

    // "오프라인 버전에서는 지원하지 않는 기능입니다." / "인벤토리가 부족합니다." (EUC-KR)
    static final byte[] MSG_OFFLINE = {-65, -64, -57, -63, -74, -13, -64, -50, 32, -71, -10, -64, -4, -65, -95, -68, -83, -76, -62, 32, -63, -10, -65, -8, -57, -49, -63, -10, 32, -66, -54, -76, -62, 32, -79, -30, -76, -55, -64, -44, -76, -49, -76, -39, 46};
    static final byte[] MSG_BAG_FULL = {-64, -50, -70, -91, -59, -28, -72, -82, -80, -95, 32, -70, -50, -63, -73, -57, -43, -76, -49, -76, -39, 46};

    void request(int cmd, byte[] pl) {
        if (LOG) rt.log("[GcServer] req " + Integer.toHexString(cmd) + " " + hexdump(pl));
        switch (cmd) {
            case 0x191: reply(0x192, 0, new byte[16]); return;             // login: 16-byte session key -> [0x1637588]
            case 0x2bd: reply(0x2be, 0, new byte[5]); return;              // notices: u32, u8 count (0)
            // paid item (billing), product = [0x1637790]: chest keys, revive scroll.
            // 0x66 handler 0x207ac: payload[2] == 0 -> the game rolls the chest's mobile items itself (0x8e88);
            // revive (0x13ebc) reads nothing. Free: always succeed.
            case 0x65: reply(0x66, 0, new byte[4]); return;
            case 0x1f5: search(0x1f6, pl, false); return;                  // trade: search by type/grade/level
            case 0x1fb: search(0x1fc, pl, true); return;                   // trade: search by name (lists everything)
            case 0x1fd: reply(0x1fe, 0, new byte[1]); return;              // my items on sale: none
            case 0x1f7: buy(pl); return;
            case 0x25b: reply(0x25c, 0, new byte[1]); return;              // mailbox list: empty
            case 0x1f9: unsell(pl); refuse(0x1fa, MSG_OFFLINE); return;   // sell: refused, item given back
            default: refuse(cmd + 1, MSG_OFFLINE);
        }
    }

    // ------------------------------------------------------------------ free shop

    /** item tables: type -> count (ConstData records, see the constructors 0x51d0/0x5758/0x5838/0x58c0/0x5988/0x5a30) */
    static final int[] COUNT = {0, 20, 30, 22, 26, 26, 26, 33, 28, 33, 33, 9, 23, 32, 85, 66};

    /** bag table per type (handler 0x130 / 0x82b4) */
    static int bagBase(int t) {
        return t <= 10 ? 0x162DF70 : t == 11 ? 0x162C44C : t == 12 ? 0x162E864 : t == 13 ? 0x162D424 : t == 14 ? 0x162BF10 : 0x1629980;
    }

    static int bodySize(int t) {
        return t <= 11 ? 40 : t == 12 ? 12 : 16;
    }

    /** stack count field (0x60fc) or -1 */
    static int countOff(int t) {
        return t <= 11 ? -1 : t == 12 ? 7 : t == 13 ? 13 : t == 14 ? 11 : 10;
    }

    private int scratch;
    private final int[] a1 = new int[1], a2 = new int[2], a4 = new int[4];

    /** build the bag body of item id into scratch with the game's constructors (no bag side effect); returns its size */
    int makeItem(int id, int grade) {
        if (scratch == 0) scratch = rt.alloc(64);
        rt.mem.fill(scratch, 0, 64);
        int t = (id >> 8) & 0xFF;
        a2[0] = scratch;
        a2[1] = id;
        if (t <= 10) {
            a4[0] = scratch; a4[1] = grade; a4[2] = id; a4[3] = 1;
            rt.cpu.call(0x51D0 | 1, a4);
        } else rt.cpu.call((t == 11 ? 0x5758 : t == 12 ? 0x5838 : t == 13 ? 0x58C0 : t == 14 ? 0x5988 : 0x5A30) | 1, a2);
        int co = countOff(t);
        if (co >= 0) {
            a1[0] = id;
            int max = rt.cpu.call(0x62B4 | 1, a1);
            rt.mem.write8(scratch + co, max < 1 ? 1 : max > 99 ? 99 : max);
        }
        return bodySize(t);
    }

    // current page: listing id -> body (what the player saw is what the player gets)
    private final int[] pageIds = new int[20];
    private final byte[][] pageBodies = new byte[20][];
    private int pageN;

    void search(int replyCmd, byte[] pl, boolean byName) {
        // payload: u32 ?, u32 first index (page * 20, RIGHT key = next page), u32 per page (20), u8 type, grade, level, sort
        int start = pl.length >= 8 ? (pl[4] & 0xFF) | ((pl[5] & 0xFF) << 8) : 0;
        int per = pl.length >= 12 ? pl[8] & 0xFF : 20;
        if (per < 1 || per > 20) per = 20;
        int type = 0xFF, grade = 0xFF, level = 0xFF;
        if (!byName && pl.length >= 16) {
            type = pl[12] & 0xFF;
            grade = pl[13] & 0xFF;
            level = pl[14] & 0xFF;
        }
        int g = grade == 0xFF ? 4 : grade > 4 ? 4 : grade;   // "all grades": the best one
        java.io.ByteArrayOutputStream hdr = new java.io.ByteArrayOutputStream(), body = new java.io.ByteArrayOutputStream();
        int skip = start, n = 0;
        for (int t = 1; t <= 15 && n < per; t++) {
            if (type != 0xFF && type != t) continue;
            if (level != 0xFF && t > 10) continue;               // only equipment has a level
            if (grade != 0xFF && t > 10) continue;               // only equipment has a grade
            for (int i = 0; i < COUNT[t] && n < per; i++) {
                int id = (t << 8) | i;
                int sz = makeItem(id, g);
                if (rt.mem.read8(scratch + 4) == 0) continue;    // no name: unused record
                if (level != 0xFF) {
                    int lv = rt.mem.read8(scratch + 5);
                    if (lv < level * 10 + 1 || lv > level * 10 + 10) continue;
                }
                if (skip > 0) { skip--; continue; }
                byte[] b = rt.mem.readBytes(scratch, sz);
                int lid = 0x01000000 | (g << 16) | id;
                pageIds[n] = lid;
                pageBodies[n] = b;
                int co = countOff(t);
                int cnt = co >= 0 ? b[co] & 0xFF : 1;
                hdr.write(lid); hdr.write(lid >> 8); hdr.write(lid >> 16); hdr.write(lid >>> 24);
                hdr.write(id); hdr.write(id >> 8);
                hdr.write(cnt); hdr.write(0);
                hdr.write(0); hdr.write(0); hdr.write(0); hdr.write(0); // price 0 GP
                body.write(b, 0, b.length);
                n++;
            }
        }
        pageN = n;
        byte[] h = hdr.toByteArray(), bd = body.toByteArray();
        byte[] p = new byte[1 + h.length + bd.length];
        p[0] = (byte) n;
        System.arraycopy(h, 0, p, 1, h.length);
        System.arraycopy(bd, 0, p, 1 + h.length, bd.length);
        reply(replyCmd, 0, p);
    }

    /** put a bag body back into the first free slot of its table; false = bag full */
    boolean putBag(byte[] b, int off) {
        int id = (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8);
        int t = (id >> 8) & 0xFF, base = bagBase(t), sz = bodySize(t);
        if (id == 0 || off + sz > b.length) return false;
        for (int i = 0; i < 40; i++) {
            if (rt.mem.read16(base + i * sz) == 0) {
                rt.mem.writeBytes(base + i * sz, b, off, sz);
                a1[0] = id;
                rt.cpu.call(0x7D9C | 1, a1);                    // item-count bookkeeping, as after every bag add (0x8584)
                rt.log("[GcServer] bag " + Integer.toHexString(id) + " -> slot " + i);
                return true;
            }
        }
        return false;
    }

    /**
     * Sell request (builder 0x202a8): the game has already taken the item out of the bag (and compacted it).
     * Payload: session[16], u16 id, name[30], u32 price, body at 0x34 (sold count in its stack field).
     */
    void unsell(byte[] pl) {
        if (pl.length > 0x34 + 12) putBag(pl, 0x34);
    }

    void buy(byte[] pl) {
        int lid = pl.length >= 20 ? (pl[16] & 0xFF) | ((pl[17] & 0xFF) << 8) | ((pl[18] & 0xFF) << 16) | ((pl[19] & 0xFF) << 24) : 0;
        byte[] b = null;
        for (int i = 0; i < pageN; i++) if (pageIds[i] == lid) b = pageBodies[i];
        int id = lid & 0xFFFF;
        if (b == null) {
            if ((lid >>> 24) != 1) { refuse(0x1f8, MSG_OFFLINE); return; }
            b = rt.mem.readBytes(scratch, makeItem(id, (lid >> 16) & 0xFF));
        }
        if (!putBag(b, 0)) { refuse(0x1f8, MSG_BAG_FULL); return; }
        reply(0x1f8, 0, new byte[0]);                           // 0x1f8: price (0) taken, game saved (0x7b8c)
    }
}
