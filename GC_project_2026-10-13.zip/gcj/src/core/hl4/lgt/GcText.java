package hl4.lgt;

import hl4.core.VnFont;
import hl4.cpu.Cpu;
import hl4.cpu.Memory;

/**
 * GrandChase Vietnamese text. The game's text module (0x35358..0x38b90) converts every EUC-KR string
 * to an array of 16-bit Unicode units (0x375cc), measures it (0x379d0) and draws it unit by unit
 * (0x37ee8). Three call-site families are redirected here:
 * <ul>
 * <li>conv: the Korean string is looked up in the dictionary (whole string, then fragments); a
 * translated string becomes units 0xE000+n (n = font glyph index), Hangul that stays untranslated
 * is converted exactly as the game does; untranslated strings go to the original 0x375cc;</li>
 * <li>measure: units of the Vietnamese font are summed here, all other units are measured by the
 * original function (called on a copy of the array without the Vietnamese units);</li>
 * <li>glyph: a Vietnamese unit is drawn with the game's own fill-rect 0x2548 in the current text
 * colour; other units go to the original glyph routine.</li>
 * </ul>
 * Layout (line breaks '|', 15 px line pitch, char-wise wrapping, colour escapes @d) stays the game's.
 */
final class GcText {
    static final int CONV = 0x375cc, MEASURE = 0x379d0, GLYPH = 0x37ee8, FILLRECT = 0x2548;
    static final int G_BUF = 0x163db3c, G_LEN = 0x163dba8, G_TABLE = 0x163db70, G_COLOR = 0x1633df4, G_SCALE = 0x163db84;
    static final int G_PIXFMT = 0x1633e18, G_SHIFT = 0x1633e3c;
    static final int[] CONV_SITES = {0x3865a, 0x386d8, 0x387c4, 0x388e6, 0x38988, 0x38a6a};
    static final int[] MEASURE_SITES = {0x3866a, 0x386e4, 0x387d0, 0x38994, 0x38a7a};
    static final int[] GLYPH_SITES = {0x3869e, 0x38728, 0x38784, 0x38840, 0x388a0, 0x38924, 0x389d8, 0x38a34,
        0x38aae, 0x38ade, 0x38b0e, 0x38b3e, 0x38b76};
    static final int CONV_LIT = 0x35418, GLYPH_LIT = 0x35434;   // literal pool words (thunks 0x375cd / 0x37ee9)
    static final int STUB_BASE = 0x45000;
    static final int UBASE = 0xE000;
    static final int ID_CONV = 110, ID_MEASURE = 111, ID_GLYPH = 112;

    private final LgtRuntime rt;
    private final Cpu cpu;
    private final Memory mem;
    private final VnFont font;
    private final GcDict dict;
    private final char[] chars;            // glyph index -> char
    private final int[] adv;
    private final int[][] rects;           // per glyph: x,y,w,h ...
    private final int yOff;
    private final int scratch;
    private final int[] gargs = new int[6];
    private final int[] fargs = new int[6];
    private final int[] cargs = new int[1], margs = new int[2];
    public int convCalls, convHit, convFrag;
    public boolean log = System.getProperty("gclog") != null;

    GcText(LgtRuntime rt, VnFont font, byte[] dictData) {
        this.rt = rt;
        this.cpu = rt.cpu;
        this.mem = rt.mem;
        this.font = font;
        this.dict = new GcDict(dictData);
        chars = font.chars();
        adv = new int[chars.length];
        rects = new int[chars.length][];
        for (int i = 0; i < chars.length; i++) adv[i] = font.advance(chars[i]);
        // Hangul glyphs: 11 rows, baseline near row 9
        yOff = 9 - font.baseline();
        scratch = rt.alloc(4096);
        fargs[5] = 16;
    }

    private int checkBl(int site, int target) {
        int h1 = mem.read16(site), h2 = mem.read16(site + 2);
        if ((h1 & 0xF800) != 0xF000 || (h2 & 0xF800) != 0xF800)
            throw new RuntimeException("GcText: no BL at " + Integer.toHexString(site));
        int off = ((h1 & 0x7FF) << 12) | ((h2 & 0x7FF) << 1);
        if ((off & 0x400000) != 0) off -= 0x800000;
        int t = site + 4 + off;
        if (t != target) throw new RuntimeException("GcText: BL at " + Integer.toHexString(site) + " -> " + Integer.toHexString(t));
        return site;
    }

    void install() {
        // stubs inside the 64 KB page of the image (free space after .text), so BL (+-4 MB) reaches them
        int sc = cpu.makeStub(STUB_BASE, (LgtRuntime.CAT_HLE << 16) | ID_CONV);
        int sm = cpu.makeStub(STUB_BASE + 8, (LgtRuntime.CAT_HLE << 16) | ID_MEASURE);
        int sg = cpu.makeStub(STUB_BASE + 16, (LgtRuntime.CAT_HLE << 16) | ID_GLYPH);
        for (int i = 0; i < CONV_SITES.length; i++) rt.patchBL(checkBl(CONV_SITES[i], CONV), sc & ~1);
        for (int i = 0; i < MEASURE_SITES.length; i++) rt.patchBL(checkBl(MEASURE_SITES[i], MEASURE), sm & ~1);
        for (int i = 0; i < GLYPH_SITES.length; i++) rt.patchBL(checkBl(GLYPH_SITES[i], GLYPH), sg & ~1);
        if (mem.read32(CONV_LIT) != (CONV | 1) || mem.read32(GLYPH_LIT) != (GLYPH | 1))
            throw new RuntimeException("GcText: unexpected thunk literals");
        mem.write32(CONV_LIT, sc);
        mem.write32(GLYPH_LIT, sg);
    }

    // ------------------------------------------------------------------ conv

    private final byte[] key = new byte[4096];
    private final int[] units = new int[2048];
    private int nUnits;

    /** HLE: replacement of 0x375cc(str): fills the unit buffer, returns its address. */
    void conv() {
        int str = cpu.r[0];
        convCalls++;
        if (log && convCalls < 8) rt.log("gc conv str=" + Integer.toHexString(str) + " lr=" + Integer.toHexString(cpu.r[14]));
        int n = 0;
        while (n < key.length - 1) {
            int b = mem.read8(str + n);
            if (b == 0) break;
            key[n++] = (byte) b;
        }
        nUnits = 0;
        if (n > 0 && translate(key, n)) {
            int maxW = wrapWidth(cpu.r[14] & ~1, cpu.r[13]);
            if (maxW > 0) { wrap(maxW); if (log && wrapLogs++ < 40) rt.log("gc WRAP lr=" + Integer.toHexString(cpu.r[14] & ~1) + " w=" + maxW + " n=" + nUnits + " brk=" + wrapBrk + " scale=" + mem.read8(G_SCALE + 2)); }
            else if (log) logLr(cpu.r[14] & ~1, n);
            int buf = mem.read32(G_BUF);
            int u = nUnits;
            if (u > 990) u = 990;
            for (int i = 0; i < u; i++) {
                int v = units[i];
                mem.write8(buf + 2 * i, v & 0xFF);
                mem.write8(buf + 2 * i + 1, v >> 8);
            }
            mem.write32(G_LEN, 2 * u);
            cpu.r[0] = buf;
        } else {
            if (log && n > 0) logKey("MISS", key, n);
            cargs[0] = str;
            cpu.r[0] = cpu.call(CONV | 1, cargs);
        }
    }

    private int[] seenLr = new int[64];
    private int nSeenLr;

    private void logLr(int lr, int n) {
        for (int i = 0; i < nSeenLr; i++) if (seenLr[i] == lr) return;
        if (nSeenLr < seenLr.length) seenLr[nSeenLr++] = lr;
        rt.log("gc NOWRAP lr=" + Integer.toHexString(lr) + " n=" + n + " sp=" + Integer.toHexString(cpu.r[13]));
    }

    private void logKey(String tag, byte[] k, int n) {
        StringBuffer sb = new StringBuffer("gc ").append(tag).append(' ');
        for (int i = 0; i < n; i++) { int b = k[i] & 0xFF; sb.append((char) ("0123456789abcdef".charAt(b >> 4))).append("0123456789abcdef".charAt(b & 15)); }
        rt.log(sb.toString());
    }

    /** Translate key[0..n) into units[]; false = leave to the game. */
    private boolean translate(byte[] k, int n) {
        int h = GcDict.hash(k, 0, n);
        int s = dict.find(h, n, false);
        if (s >= 0) {
            convHit++;
            emitVn(dict.buf(), dict.decode(s));
            return true;
        }
        if (!dict.hasFragments()) return false;
        // fragments, longest first
        boolean any = false;
        int p = 0, plain = 0;
        nUnits = 0;
        while (p < n) {
            int bestL = 0;
            int bestS = -1;
            int fh = GcDict.FNV0;
            int max = Math.min(dict.maxFrag(), n - p);
            for (int l = 1; l <= max; l++) {
                fh = GcDict.step(fh, k[p + l - 1]);
                if (dict.fragLen(l)) {
                    int r = dict.find(fh, l, true);
                    if (r >= 0) { bestL = l; bestS = r; }
                }
            }
            if (bestL > 0) {
                if (plain < p) emitKorean(k, plain, p);
                emitVn(dict.buf(), dict.decode(bestS));
                p += bestL;
                plain = p;
                any = true;
            } else {
                int b = k[p] & 0xFF;
                p += (b > 0xA0 && p + 1 < n) ? 2 : 1;
            }
        }
        if (!any) return false;
        if (plain < n) { emitKorean(k, plain, n); if (log) logKey("PART", k, n); }
        convFrag++;
        return true;
    }

    private void put(int u) {
        if (nUnits < units.length) units[nUnits++] = u;
    }

    private int glyphIndex(char c) {
        int lo = 0, hi = chars.length - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (chars[mid] == c) return mid;
            if (chars[mid] < c) lo = mid + 1; else hi = mid - 1;
        }
        return -1;
    }

    /** s[0..len): decoded translation */
    private void emitVn(char[] s, int len) {
        for (int i = 0; i < len; i++) {
            char c = s[i];
            if (c == '|' || c == '\n') { put(0x7C); continue; }
            if (c == '@' && i + 1 < len && s[i + 1] >= '0' && s[i + 1] <= '9') {   // colour escape stays the game's
                put('@');
                put(s[i + 1]);
                i++;
                continue;
            }
            int g = glyphIndex(c);
            if (g >= 0) put(UBASE + g);
        }
    }

    /** the game's EUC-KR -> unit conversion (0x375cc) for bytes [a, b) */
    private void emitKorean(byte[] k, int a, int b) {
        int tbl = mem.read32(G_TABLE);
        for (int i = a; i < b; i++) {
            int c = k[i] & 0xFF;
            if (c > 0xAF) {
                i++;
                int c2 = i < b ? k[i] & 0xFF : 0;
                int idx = (((c + 0x50) & 0xFF) * 0x5E + ((c2 + 0x5F) & 0xFF));
                int code = (mem.read8(tbl + idx * 2) << 8) | mem.read8(tbl + idx * 2 + 1);
                int cho = ((code >> 10) & 0x1F) - 2;
                int jung = (code >> 5) & 0x1F;
                int jong = code & 0x1F;
                int r7 = jung > 0x17 ? 6 : jung > 0xF ? 4 : jung > 7 ? 2 : 0;
                int ji = jung - r7 - 3;
                jong = jong > 0x11 ? jong - 2 : jong - 1;
                put((((cho * 21 + ji) * 28 + jong) + 0xAC00) & 0xFFFF);
            } else if (c > 0xA3) {
                i++;
                int c2 = i < b ? k[i] & 0xFF : 0;
                put(0x3100 | ((c2 - 0x70) & 0xFF));
            } else if (c > 0x1F) {
                put(c);
            }
        }
    }


    // ------------------------------------------------------------------ word wrap

    private int wrapBrk, wrapLogs;
    private final int[] rawAdv = new int[128];
    private int spaceUnit = -1;
    private int[] wrapTmp = new int[2048];

    /** limit (px) of the caller's line, 0 = do not wrap. Sites: multi-line draw wrappers + typewriter dialogue. */
    private int wrapWidth(int lr, int sp) {
        switch (lr) {
            case 0x386dc: case 0x3898c: wrapBrk = 0x7C; return mem.read32(sp + 0x2C);
            case 0x387c8: wrapBrk = 0x7C; return mem.read32(sp + 0x30);
            case 0x35380: wrapBrk = 0x2F; return dlgWidth();
            case 0x388ea: wrapBrk = 0x2F; return mem.read32(sp + 0x30);
            default: return 0;
        }
    }

    private int dlgWidth() {
        int v = mem.read16(0x162A0B0);
        if (v >= 0x8000) v -= 0x10000;
        return v - 0x37;
    }

    private int unitWidth(int u, int scale) {
        if (isVn(u)) return adv[u - UBASE] * scale;
        if (u < 128) {
            int w = rawAdv[u];
            if (w == 0) {
                mem.write8(scratch, u);
                mem.write8(scratch + 1, 0);
                margs[0] = scratch; margs[1] = 2;
                w = cpu.call(MEASURE | 1, margs) + 1;   // +1: cache marker
                rawAdv[u] = w;
            }
            return w - 1;
        }
        return -1;
    }

    /** greedy word wrap of units[0..nUnits) at maxW px; line breaks replace the space. Untranslated Hangul: left to the game. */
    private void wrap(int maxW) {
        if (spaceUnit < 0) spaceUnit = UBASE + glyphIndex(' ');
        int scale = mem.read8(G_SCALE + 2);
        if (scale == 0) scale = 1;
        int n = nUnits;
        int lineW = 0, lastSp = -1, wAtSp = 0, spW = 0;
        boolean breakDone = false;
        for (int i = 0; i < n; i++) {
            int u = units[i];
            if (u == '@' && i + 1 < n && units[i + 1] >= '0' && units[i + 1] <= '9') { i++; continue; }
            if (u == 0x7C || u == 0x2F) { lineW = 0; lastSp = -1; continue; }
            int w = unitWidth(u, scale);
            if (w < 0) return;          // raw Hangul etc.: do not touch
            if (u == spaceUnit || u == 0x20) {
                if (lineW == 0) continue;
                lastSp = i; wAtSp = lineW; spW = w;
                lineW += w;
                continue;
            }
            lineW += w;
            if (lineW > maxW && lastSp >= 0) {
                units[lastSp] = wrapBrk;
                lineW -= wAtSp + spW;
                lastSp = -1;
            } else if (lineW > maxW) {
                lineW = w;              // single over-long word: the game wraps by character
            }
        }
    }

    // ------------------------------------------------------------------ measure

    private boolean isVn(int u) {
        return u >= UBASE && u < UBASE + chars.length;
    }

    /** HLE: replacement of 0x379d0(buf, len). */
    void measure() {
        int buf = cpu.r[0], len = cpu.r[1];
        int vn = 0, raw = 0;
        int sw = 0;
        for (int i = 0; i + 1 < len; i += 2) {
            int u = mem.read8(buf + i) | (mem.read8(buf + i + 1) << 8);
            if (isVn(u)) sw += adv[u - UBASE]; else raw++;
            if (isVn(u)) vn++;
        }
        if (vn == 0) {
            margs[0] = buf; margs[1] = len;
            cpu.r[0] = cpu.call(MEASURE | 1, margs);
            return;
        }
        int o = 0;
        for (int i = 0; i + 1 < len; i += 2) {
            int lo = mem.read8(buf + i), hi = mem.read8(buf + i + 1);
            if (isVn(lo | (hi << 8))) continue;
            mem.write8(scratch + o, lo);
            mem.write8(scratch + o + 1, hi);
            o += 2;
        }
        int w = 0;
        if (o > 0) { margs[0] = scratch; margs[1] = o; w = cpu.call(MEASURE | 1, margs); }
        int scale = mem.read8(G_SCALE + 2);
        cpu.r[0] = w + sw * (scale == 0 ? 1 : scale);
    }

    // ------------------------------------------------------------------ glyph

    /** HLE: replacement of 0x37ee8(buf, idx, x, y, xoff, yoff) -> new xoff. */
    void glyph() {
        int buf = cpu.r[0], idx = cpu.r[1], x = cpu.r[2], y = cpu.r[3];
        int sp = cpu.r[13];
        int xoff = mem.read32(sp), yoff = mem.read32(sp + 4);
        int u = mem.read8(buf + idx) | (mem.read8(buf + idx + 1) << 8);
        if (!isVn(u)) {
            gargs[0] = buf; gargs[1] = idx; gargs[2] = x; gargs[3] = y; gargs[4] = xoff; gargs[5] = yoff;
            cpu.r[0] = cpu.call(GLYPH | 1, gargs);
            return;
        }
        int g = u - UBASE;
        int gx = x + xoff, gy = y + yoff + yOff;
        int pix = mem.read32(G_COLOR) & 0xFFFF;
        if (gy > -40 && gy < 400 && gx > -40 && pix != 0xF81F) drawGlyph(g, gx, gy, pix);
        int scale = mem.read8(G_SCALE + 2);
        cpu.r[0] = xoff + adv[g] * (scale == 0 ? 1 : scale);
    }

    private void drawGlyph(int g, int gx, int gy, int pix) {
        int[] r = rects[g];
        if (r == null) r = rects[g] = buildRects(chars[g]);
        if (r.length == 0) return;
        // pix -> rgb888 (inverse of 0x2114)
        int shR = mem.read8(G_SHIFT), shG = mem.read8(G_SHIFT + 1);
        boolean g6 = mem.read8(G_PIXFMT) == 1;
        int rr = (pix >> shR) & 0x1F;
        int gg = (pix >> shG) & (g6 ? 0x3F : 0x1F);
        int bb = pix & 0x1F;
        int rgb = (((rr << 3) | (rr >> 2)) << 16) | (((g6 ? (gg << 2) | (gg >> 4) : (gg << 3) | (gg >> 2))) << 8) | ((bb << 3) | (bb >> 2));
        fargs[4] = rgb;
        for (int i = 0; i < r.length; i += 4) {
            fargs[0] = gx + r[i];
            fargs[1] = gy + r[i + 1];
            fargs[2] = r[i + 2];
            fargs[3] = r[i + 3];
            cpu.call(FILLRECT | 1, fargs);
        }
    }

    /** horizontal runs merged vertically into rectangles: x, y, w, h */
    private int[] buildRects(char c) {
        int[] px = font.pixels(c);
        if (px == null || px.length == 0) return new int[0];
        int h = font.height, w = font.advance(c);
        boolean[] on = new boolean[w * h];
        for (int i = 0; i < px.length; i++) on[(px[i] >> 8) * w + (px[i] & 0xFF)] = true;
        int[] out = new int[4 * w * h];
        int n = 0;
        boolean[] used = new boolean[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (!on[y * w + x] || used[y * w + x]) continue;
                int rw = 1;
                while (x + rw < w && on[y * w + x + rw] && !used[y * w + x + rw]) rw++;
                int rh = 1;
                outer:
                while (y + rh < h) {
                    for (int k = 0; k < rw; k++) if (!on[(y + rh) * w + x + k] || used[(y + rh) * w + x + k]) break outer;
                    rh++;
                }
                for (int yy = 0; yy < rh; yy++) for (int k = 0; k < rw; k++) used[(y + yy) * w + x + k] = true;
                out[n++] = x; out[n++] = y; out[n++] = rw; out[n++] = rh;
            }
        }
        int[] res = new int[n];
        System.arraycopy(out, 0, res, 0, n);
        return res;
    }
}
