package hl4.lgt;

/**
 * GrandChase translation dictionary (gc/tools/build_gcvi.py).
 * <pre>
 *   u4 magic 'GCV1', u4 n,
 *   n x { u4 fnv1a(korean EUC-KR bytes), u2 key length, u1 flags (1 = fragment), u4 value offset }  sorted by hash (unsigned),
 *   u4 blobLen, blob: per value u2 byte length + UTF-8 text
 * </pre>
 */
final class GcDict {
    static final int FNV0 = 0x811C9DC5;
    private final int n;
    private final int[] hash, klen, voff;
    private final byte[] flags;
    private final byte[] blob;
    private int maxFrag;
    private boolean[] fragLens = new boolean[0];
    private boolean frags;
    private final char[] tmp = new char[2048];

    static int step(int h, int b) {
        return (h ^ (b & 0xFF)) * 0x01000193;
    }

    static int hash(byte[] k, int off, int len) {
        int h = FNV0;
        for (int i = 0; i < len; i++) h = step(h, k[off + i]);
        return h;
    }

    private static int i4(byte[] d, int o) {
        return ((d[o] & 0xFF) << 24) | ((d[o + 1] & 0xFF) << 16) | ((d[o + 2] & 0xFF) << 8) | (d[o + 3] & 0xFF);
    }

    GcDict(byte[] d) {
        if (i4(d, 0) != 0x47435631) throw new RuntimeException("GcDict: bad magic");
        n = i4(d, 4);
        hash = new int[n];
        klen = new int[n];
        voff = new int[n];
        flags = new byte[n];
        int o = 8;
        for (int i = 0; i < n; i++) {
            hash[i] = i4(d, o);
            klen[i] = ((d[o + 4] & 0xFF) << 8) | (d[o + 5] & 0xFF);
            flags[i] = d[o + 6];
            voff[i] = i4(d, o + 7);
            o += 11;
        }
        int bl = i4(d, o);
        blob = new byte[bl];
        System.arraycopy(d, o + 4, blob, 0, bl);
        for (int i = 0; i < n; i++) {
            if ((flags[i] & 1) != 0) {
                frags = true;
                if (klen[i] > maxFrag) maxFrag = klen[i];
            }
        }
        fragLens = new boolean[maxFrag + 1];
        for (int i = 0; i < n; i++) if ((flags[i] & 1) != 0) fragLens[klen[i]] = true;
    }

    boolean hasFragments() { return frags; }
    int maxFrag() { return maxFrag; }
    boolean fragLen(int l) { return l <= maxFrag && fragLens[l]; }

    /** value offset for (hash, length) or -1; fragment entries only when frag is true */
    int find(int h, int len, boolean frag) {
        int lo = 0, hi = n - 1;
        // unsigned binary search
        long key = h & 0xFFFFFFFFL;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            long m = hash[mid] & 0xFFFFFFFFL;
            if (m < key) lo = mid + 1; else if (m > key) hi = mid - 1; else {
                int i = mid;
                while (i > 0 && hash[i - 1] == h) i--;
                for (; i < n && hash[i] == h; i++) {
                    if (klen[i] == len && (!frag || (flags[i] & 1) != 0)) return voff[i];
                }
                return -1;
            }
        }
        return -1;
    }

    char[] buf() { return tmp; }

    /** decode the value at off into buf(); returns its length (no allocation) */
    int decode(int off) {
        int len = ((blob[off] & 0xFF) << 8) | (blob[off + 1] & 0xFF);
        int p = off + 2, e = p + len, c = 0;
        while (p < e && c < tmp.length) {
            int b = blob[p++] & 0xFF;
            if (b < 0x80) tmp[c++] = (char) b;
            else if (b < 0xE0) tmp[c++] = (char) (((b & 0x1F) << 6) | (blob[p++] & 0x3F));
            else { tmp[c++] = (char) (((b & 0x0F) << 12) | ((blob[p] & 0x3F) << 6) | (blob[p + 1] & 0x3F)); p += 2; }
        }
        return c;
    }
}
