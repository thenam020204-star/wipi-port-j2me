#!/bin/bash
# Build GrandChase (LGT WIPI) -> J2ME jar.   usage: ./makegc.sh [suffix]   -> distgc/GC_LGT<suffix>.jar/.jad
set -e
W=/home/claude/work; cd $W
export JAVA_TOOL_OPTIONS=
[ -d gc/jar ] || { mkdir -p gc/orig gc/jar; unzip -q -o GC.zip -d gc/orig; (cd gc/jar && unzip -q -o ../orig/*.jar); }
(cd gcj && ./tbuild.sh build/t 2>&1 | grep -v JAVA_TOOL || true)
rm -rf gc/overlay gc/snd && mkdir -p gc/overlay/SND gc/snd
java -cp gcj/build/t SndConvert5 gc/jar gc/snd /
cp gc/snd/*.mid gc/snd/*.wav gc/snd/*.mmf gc/overlay/ 2>/dev/null || true
mv gc/snd/list.txt gc/overlay/SND/list.txt 2>/dev/null || true
[ -d gc/extra ] && cp -r gc/extra/. gc/overlay/
(cd gcj && OVERLAY=$W/gc/overlay SUFFIX=$1 ./build.sh $W/GC.zip $W/distgc)
ls -l distgc
