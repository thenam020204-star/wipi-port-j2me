#!/bin/bash
# Đồng bộ mã nguồn + bản dịch Zenonia 1/2 vào repo /home/user/game/xenonia (không copy jar gốc, build, out, catalog).
exec python3 - <<'P'
import shutil, os
W='/home/claude/work'; R='/home/user/game/xenonia'
ign=shutil.ignore_patterns('__pycache__','build','out','catalog.json',)
def tree(s,d):
    d=os.path.join(R,d)
    if os.path.exists(d): shutil.rmtree(d)
    shutil.copytree(os.path.join(W,s),d,ignore=ign)
for s in ['xen/vi','xen/tools','xen/img','xen2/vi','xenj/src','xenj/test','xenj/tools','xenj/aot','xenj/profiles']: tree(s,s)
for f in ['xenj/build.sh','xenj/tbuild.sh','make_xen.sh','sync_repo.sh']: shutil.copy(os.path.join(W,f),os.path.join(R,f))
shutil.rmtree(os.path.join(R,'release_xen'),ignore_errors=True); os.makedirs(os.path.join(R,'release_xen'))  # chỉ giữ bản phát hành hiện tại
for f in os.listdir(os.path.join(W,'release_xen')): shutil.copy(os.path.join(W,'release_xen',f),os.path.join(R,'release_xen',f))
print('synced')
P
