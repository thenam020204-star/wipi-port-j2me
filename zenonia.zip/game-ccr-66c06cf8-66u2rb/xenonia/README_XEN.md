# Zenonia 1 & 2 (제노니아, Gamevil, LGT WIPI) → J2ME, Việt hoá

Bản phát hành (thư mục `release_xen/`, mỗi zip = jar + jad, chạy FreeJ2ME Plus / máy MIDP2):
- `XEN_LGT_vi5.zip` — Zenonia 1 Việt hoá (vi1 = Việt hoá đầu, vi2 = sửa crash + AOT, vi3/vi4 = logo NAMP, bỏ menu mạng, ảnh,
  sửa chữ đè, vi5 = sửa các câu thông báo về đồ cash cho đúng với bản đã gỡ mạng).
- `XEN2_LGT_vi2.zip` — Zenonia 2: The Lost Memories, Việt hoá toàn bộ, AOT (vi1), vi2 = cửa hàng cash chạy offline, miễn phí.

Engine = bản sao nhánh HL5 (`xenj/`, trình thông dịch ARM Thumb + WIPI-C HLE), không đụng `hl4j/`, `hl5j/`.

| | Zenonia 1 | Zenonia 2 |
|---|---|---|
| gốc | `XEN.zip`, AID 00027BAA | `XEN2.zip`, AID 0002C004 |
| `binary.mod` .text | 0x1000, 0x651bc @ file 0x34 | 0x1000, 0x8b538 @ file 0x34 |
| thư mục | `xen/` | `xen2/` (dùng chung `xen/tools`, `xen/img`) |
| mục dịch | 4246 (3841 câu khác nhau) | 6491 (5945 câu khác nhau) |
| AOT | `xenj/aot/xen1` (98,4%) | `xenj/aot/xen2` (98,7%, ~8×) |

## Build
```
VI=1 ./make_xen.sh _vi5            # Zenonia 1 -> dist_xen/XEN_LGT_vi5.jar/.jad
GAME=2 VI=1 ./make_xen.sh _vi2     # Zenonia 2 -> dist_xen/XEN2_LGT_vi2.jar/.jad
```
Cần `xen/jar`, `xen2/jar` = jar gốc đã bung, `XEN.zip`, `XEN2.zip`. `make_xen.sh`: âm thanh SMAF→mid/wav,
chép overlay Việt hoá `<dir>/vi/build/overlay`, logo NAMP (`xen/img/mk_logo.py`), ảnh có chữ Hàn
(`xen/img/mk_images.py`; Zenonia 1 thêm `mk_title1.py`), rồi `xenj/build.sh` (kèm AOT nếu có).

## Việt hoá (`<dir>/vi/`)
1. `extract.py` → `catalog.json` + `out/XEN_dich.tsv`. ID: `S:file:i` (GST), `X:file:r:c` (GXL, ô cố định),
   `D:i` (script/output.dlg), `B:addr` (chuỗi trong binary, ô = tới chuỗi kế), `G:file:off` (*.gui, u8 độ dài).
2. Bản dịch: `tr/vi_*.txt` dòng `ID<TAB>tiếng Việt` (áp cho mọi câu Hàn trùng); file `*_id.txt` chỉ áp đúng ID.
   `\n \t \r` viết dạng thoát. `<rỗng>` = chuỗi rỗng (trợ từ 은/는/이/가...).
3. `merge_tr.py && build_vi.py out/XEN_viet.tsv` → overlay + `build/bao-cao-build.txt`. `dump.py <tiền tố>` = câu chưa dịch.
- Mã hoá: mỗi từ = 2 byte (lead 0xC9.., trail 0xA1..) = dòng trong `vi/dict.txt`; `XenText` (hook vòng vẽ/đo chữ
  của game) vẽ bằng font 15px. Mã điều khiển giữ ASCII: `!N !C !L !cRRGGBB [0xRRGGBB] %s %d`.
- Ô chật: cả cụm chữ giữa hai mã điều khiển gộp thành 1 mã. Đuôi chuỗi dùng chung (vd `%d` cuối câu) được giữ đúng địa chỉ.
- `patches.txt`: vá mã `địa_chỉ mã_gốc mã_mới`. Cả hai game: menu chính bỏ hẳn mục mạng ("Mạng/Cộng đồng") và "Liên hệ"
  (Z1: 0x3bc4e/0x3ab2e/0x3ac8e; Z2: 0x5b196 danh sách 6→4 mục).
- Cửa hàng cash Zenonia 2 (vá 0x7c74): vào bằng NPC cô gái mạng trong làng → "Cộng đồng" → "Mua vật phẩm". Bấm "Có" thì thay vì
  gửi yêu cầu mạng 0x6d3c(ui, 0x11) (→ máy chủ 218.145.70.36:32006, offline sẽ báo "Lỗi mạng"), game gọi thẳng 0x9040(mục) — hàm
  game vẫn gọi khi máy chủ báo mua thành công (bảng xử lý phản hồi 0x81d2c, loại 17 → 0x92c8 → 0x9040): cho vật phẩm/gói vào túi,
  báo "Đã mua thành công", lưu game. Vẫn kiểm tra chỗ trống túi như gốc. "Viết/Đọc thư" vẫn báo lỗi mạng (không có máy chủ).
- Zenonia 1: cửa hàng cash chỉ vào được từ menu mạng ở màn hình chính, mà menu này đã bỏ hẳn → không có shop cash; các câu
  thông báo/hướng dẫn/hội thoại (B:616dc, StrHelp 9, D:1799) đã sửa thành "chức năng mạng, mua đồ cash đã được gỡ bỏ".
- Tên theo bản tiếng Anh. Z2: Lu (Thánh Kỵ Sĩ), Ecne (Xạ Thủ), Morpice (Pháp Sư), Daza (Võ Sư), tiên Lepe,
  Zavkiel (Đại Thủ Hộ), Zealous, Ladon, Tiaris, Regret, Monica, Lisa, Amos; lâu đài Deva, làng Iris, Phế Tích Raka,
  Đền Vàng, Hầm Băng, Bafor, Terador, núi lửa Crusus, Coelaum; thánh thạch (성루석), tộc Long Huyết, Thú Nhân, tộc Thiên.

## Ảnh PZX (`xen/img/pzx.py`)
`PZX\x01`, u32 off ảnh/khung/hoạt cảnh. Mỗi phần: u8 loại, u16 n, u32 off[n], u32 raw, u32 nén, zlib (n=0 → chỉ 3 byte).
Ảnh 8-bit: u8 8, u16 n, u8 1, u8 số màu, RGB565[] (màu 0 = khoá f81f); mỗi ảnh u16 w,h, u8 2, 3 đệm, u32 dài, u32 0,
token u16: 0xfffe hết dòng, 0xffff hết ảnh, 0x8000|n = n chỉ số màu, khác = bỏ qua n điểm. Khung: u16 n, n×(u16 ảnh, s16 x, s16 y, u8 cờ).
`pzx.replace_images()` thay ảnh, mở rộng bảng màu (đầy thì lấy màu gần nhất), chỉnh toạ độ trong khung.

## Kiểm thử
- Headless: `S=/tmp/x xenj/tools/xk.sh|xk2.sh <tên> <ms> <chu kỳ> "<phím>"`; `GAMEZIP=XEN2.zip xenj/tools/run.sh ... "monkey:<seed>"`
  hoặc `"seq:<ms>:<phím>;<ms>:<phím>..."` (phím UP DOWN LEFT RIGHT OK LSK RSK CLR * # số); `CP=xenj/build/t2 HL4_AOT=1` = chạy có AOT.
  `RES=<overlay>` `HL4_VI=<overlay>/vi`; `HL4_WATCH=addr HL4_WATCHMEM=reg:off:len` in thanh ghi/bộ nhớ; `HL4_PROFILE=0` ghi `profile.txt`;
  `HL4_CALLS=1` ghi log lời gọi hàm (Z2 cần `HL4_VENEER=80798`); `HL4_CALL="<ms>:<hàm>,<đối số>,...|..."` gọi một hàm của game tại
  thời điểm ms (đối số: số hex, `@addr` = đọc u32, `@addr+off` = u32 + off), in `HL4_CALL ... -> kết quả`.
- Ví dụ thử shop cash Z2 (cần save đã qua đầu game trong `<storage>`), mở UI mạng rồi đếm vật phẩm mục 0 trước/sau khi mua:
  `HL4_CALL="30000:1dd78,@1400064,9|30010:4dbc,@1400064+24c,0,0|30020:37ca4,@14000d0,@14000d0+21a8,0|52000:37ca4,@14000d0,@14000d0+21a8,0"`
  với phím `seq:...12000:DOWN;1500:DOWN;1500:OK;3000:OK;...` → số lượng 0 → 1, không có `MC_netConnect`.
- AOT: chép profile vào `xenj/profiles/xen{,2}_*.txt`, `tools/regen_xen_aot.sh` / `regen_xen2_aot.sh` (sinh từ binary ĐÃ VÁ trong
  `<dir>/overlay`), kiểm tra bằng cách chạy cùng seed với `build/t` (thông dịch) và `build/t1|t2` (`HL4_AOT=1`): số lệnh và mọi khung hình phải trùng.
- Đã chạy: monkey 2×10 phút mỗi game không lỗi; AOT khớp từng bit; FreeJ2ME Plus (Xvfb) khởi động sạch (vi5/vi2: log y hệt vi4/vi1,
  chỉ có lỗi thiết bị âm thanh của Xvfb và game dò file *.mpl không có). Shop cash Z2: thông dịch và AOT cho khung hình trùng nhau.

## Còn lại / ghi chú
- Vá mã mới: thêm dòng vào `<dir>/vi/patches.txt`, build lại overlay, chạy `regen_xen{,2}_aot.sh` (nếu chỗ vá nằm trong vùng AOT thì
  file LgtAot.java đổi; vá 0x7c74 nằm ngoài vùng AOT nên không đổi), rồi kiểm tra AOT khớp bit như trên.
- Còn ~100 mục "chưa dịch" của Z2 / 13 của Z1 là rác trong binary (không phải chữ hiển thị).
- Khung cửa sổ menu chính Zenonia 1 vẫn cao theo 6 mục (layout cố định trong dữ liệu UI).
- `sync_repo.sh` đồng bộ thư mục làm việc `/home/claude/work` vào repo.
