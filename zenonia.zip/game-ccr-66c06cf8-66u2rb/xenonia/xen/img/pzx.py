#!/usr/bin/env python3
"""Gamevil PZX (Zenonia 1/2): 'PZX\\x01', u32 img_off, u32 frame_off, u32 anim_off.
Image section: u8 bpp(8), u8 n_images, u8 0, u8 n_pal(1), u8 n_colors, u16 RGB565[n_colors] (index 0 = key f81f),
u32 raw_size, u32 zlib_size, zlib -> u32 off[n] (relative to the blob), per image:
u16 w, u16 h, u8 type(2), 3 pad, u32 data_len, u32 0, rows of u16 tokens: 0xfffe end of row,
0x8000|n -> n palette indices follow, else skip n (transparent); 0xffff ends the image."""
import struct, zlib, sys
from PIL import Image


def rgb(c):
    return ((c >> 11) & 31) * 255 // 31, ((c >> 5) & 63) * 255 // 63, (c & 31) * 255 // 31


def parse(d):
    assert d[:4] == b'PZX\x01'
    io, fo, ao = struct.unpack_from('<3I', d, 4)
    bpp, n, z, npal, ncol = d[io:io + 5]
    pal = list(struct.unpack_from('<%dH' % ncol, d, io + 5))
    p = io + 5 + 2 * ncol
    raw, comp = struct.unpack_from('<2I', d, p)
    blob = zlib.decompress(d[p + 8:p + 8 + comp])
    assert len(blob) == raw
    offs = struct.unpack_from('<%dI' % n, blob, 0)
    imgs = []
    for o in offs:
        w, h, t = struct.unpack_from('<HHB', blob, o)
        dl, = struct.unpack_from('<I', blob, o + 8)
        q = o + 16; rows = []
        for y in range(h):
            row = [None] * w; x = 0
            while True:
                v, = struct.unpack_from('<H', blob, q); q += 2
                if v == 0xfffe: break
                if v & 0x8000:
                    k = v & 0x7fff
                    for i in range(k): row[x + i] = blob[q + i]
                    q += k; x += k
                else: x += v
            rows.append(row)
        imgs.append((w, h, t, rows))
    return dict(io=io, fo=fo, ao=ao, bpp=bpp, pal=pal, imgs=imgs, head=d[io:io + 4])


def to_png(img, pal, path):
    w, h, t, rows = img
    im = Image.new('RGBA', (w, h))
    for y, r in enumerate(rows):
        for x, c in enumerate(r):
            im.putpixel((x, y), (0, 0, 0, 0) if c is None else rgb(pal[c]) + (255,))
    im.save(path)


if __name__ == '__main__':
    d = open(sys.argv[1], 'rb').read()
    P = parse(d)
    print('img@%x frame@%x anim@%x colors %d' % (P['io'], P['fo'], P['ao'], len(P['pal'])))
    for i, im in enumerate(P['imgs']):
        print(i, im[0], im[1], im[2])
        if len(sys.argv) > 2: to_png(im, P['pal'], '%s_%d.png' % (sys.argv[2], i))


def pack_section(kind_byte, items, extra=b''):
    """u8 kind, u16 n, u32 off[n], u32 raw, u32 comp, zlib(blob); n = 0 -> only the 3 bytes"""
    if not items: return bytes([kind_byte]) + b'\0\0'
    blob = b''.join(items); offs = []; o = 0
    for it in items: offs.append(o); o += len(it)
    c = zlib.compress(blob, 9)
    return bytes([kind_byte]) + struct.pack('<H', len(items)) + extra + struct.pack('<%dI' % len(items), *offs) + struct.pack('<2I', len(blob), len(c)) + c


def read_section(d, o):
    kind = d[o]; n, = struct.unpack_from('<H', d, o + 1)
    if n == 0: return kind, []
    offs = struct.unpack_from('<%dI' % n, d, o + 3)
    raw, comp = struct.unpack_from('<2I', d, o + 3 + 4 * n)
    b = zlib.decompress(d[o + 3 + 4 * n + 8:o + 3 + 4 * n + 8 + comp])
    return kind, [b[a:(offs[i + 1] if i + 1 < n else len(b))] for i, a in enumerate(offs)]


def encode_image(rows, w, h):
    """rows: list of h lists of palette index or None (transparent)"""
    out = bytearray()
    for r in rows:
        x = 0
        while x < w:
            if r[x] is None:
                k = x
                while k < w and r[k] is None: k += 1
                out += struct.pack('<H', k - x); x = k
            else:
                k = x
                while k < w and r[k] is not None and k - x < 0x7fff: k += 1
                out += struct.pack('<H', 0x8000 | (k - x)) + bytes(r[x:k]); x = k
        out += b'\xfe\xff'
    out += b'\xff\xff'                                    # end of image
    return struct.pack('<HHB', w, h, 2) + b'\xcd\xcd\xcd' + struct.pack('<II', len(out), 0) + bytes(out)


def image_section(pal, recs):
    """8-bit image section (one palette, index 0 = key colour)"""
    blob = b''; offs = []; o = 4 * len(recs)
    for r in recs: offs.append(o); o += len(r)
    blob = struct.pack('<%dI' % len(recs), *offs) + b''.join(recs)
    c = zlib.compress(blob, 9)
    return bytes([8]) + struct.pack('<H', len(recs)) + bytes([1, len(pal)]) + struct.pack('<%dH' % len(pal), *pal) + struct.pack('<2I', len(blob), len(c)) + c


def build(anim, frame, image):
    """sections in file order anim, frame, image (like logo.pzx)"""
    a = 16; f = a + len(anim); i = f + len(frame)
    return b'PZX\x01' + struct.pack('<3I', i, f, a) + anim + frame + image


def quantize(png, size, ncol=254, bg=None):
    """RGBA/RGB png -> (pal565 with key at 0, rows of indices)"""
    im = Image.open(png).convert('RGBA')
    if size and im.size != size: im = im.resize(size, Image.LANCZOS)
    w, h = im.size
    alpha = im.split()[3]
    q = im.convert('RGB').quantize(ncol, method=Image.MEDIANCUT, dither=Image.FLOYDSTEINBERG)
    p = q.getpalette()[:3 * ncol]
    pal = [0xf81f]
    for k in range(ncol):
        r, g, b = p[3 * k:3 * k + 3]
        c = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
        if c == 0xf81f: c = 0xf81e
        pal.append(c)
    px = q.load(); al = alpha.load()
    rows = [[(px[x, y] + 1) if al[x, y] >= 128 else None for x in range(w)] for y in range(h)]
    return pal, rows


def section_bytes(d):
    """raw bytes of the three sections (by header offset order)"""
    io, fo, ao = struct.unpack_from('<3I', d, 4)
    b = sorted([io, fo, ao, len(d)])
    nxt = lambda o: b[b.index(o) + 1]
    return d[io:nxt(io)], d[fo:nxt(fo)], d[ao:nxt(ao)]


def to_rows(im, pal):
    """RGBA image -> rows of palette indices (pal is extended with missing colours)"""
    im = im.convert('RGBA'); w, h = im.size; px = im.load(); rows = []
    for y in range(h):
        r = []
        for x in range(w):
            R, G, B, A = px[x, y]
            if A < 128: r.append(None); continue
            c = ((R >> 3) << 11) | ((G >> 2) << 5) | (B >> 3)
            if c == 0xf81f: c = 0xf81e
            if c not in pal[1:]:
                if len(pal) < 255: pal.append(c)
                else:                                   # palette full: nearest colour
                    best = min(range(1, len(pal)), key=lambda k: sum((p - q) ** 2 for p, q in zip(rgb(pal[k]), (R, G, B))))
                    r.append(best); continue
            r.append(pal.index(c, 1))
        rows.append(r)
    return rows


def replace_images(d, new, part_fix=None):
    """new: {index: PIL image}; part_fix(img_index, x, y, old_wh, new_wh) -> (x, y) for frame parts"""
    P = parse(d)
    pal = list(P['pal'])
    recs = []
    for i, (w, h, t, rows) in enumerate(P['imgs']):
        if i in new:
            im = new[i]; rows2 = to_rows(im, pal); recs.append(encode_image(rows2, im.width, im.height))
        else: recs.append(encode_image(rows, w, h))
    img = image_section(pal, recs)
    isec, fsec, asec = section_bytes(d)
    io, fo, ao = struct.unpack_from('<3I', d, 4)
    kind, frames = read_section(d, fo)
    nf = []
    for f in frames:
        n, = struct.unpack_from('<H', f, 0); f = bytearray(f)
        for j in range(n):
            k, x, y, fl = struct.unpack_from('<HhhB', f, 2 + 7 * j)
            if k in new and part_fix:
                ow, oh = P['imgs'][k][:2]
                x, y = part_fix(k, x, y, (ow, oh), new[k].size)
                struct.pack_into('<HhhB', f, 2 + 7 * j, k, x, y, fl)
        nf.append(bytes(f))
    fsec2 = pack_section(fsec[0], nf)
    # keep the original section order
    order = sorted([(io, 'i'), (fo, 'f'), (ao, 'a')])
    secs = {'i': img, 'f': fsec2, 'a': asec}
    out = bytearray(b'PZX\x01' + b'\0' * 12); offs = {}
    for _, k in order: offs[k] = len(out); out += secs[k]
    struct.pack_into('<3I', out, 4, offs['i'], offs['f'], offs['a'])
    return bytes(out)


def decode_png(d, i):
    P = parse(d); w, h, t, rows = P['imgs'][i]
    im = Image.new('RGBA', (w, h))
    for y, r in enumerate(rows):
        for x, c in enumerate(r):
            if c is not None: im.putpixel((x, y), rgb(P['pal'][c]) + (255,))
    return im
