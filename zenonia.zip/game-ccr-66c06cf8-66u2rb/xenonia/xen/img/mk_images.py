#!/usr/bin/env python3
"""Korean text in PZX images -> Vietnamese (pixel font pixeltext 10px).
  mk_images.py <jar dir> <overlay dir>"""
import sys, os, struct
H = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, H); sys.path.insert(0, '/home/claude/work/img5/pixeltext-kit')
import pzx
import pixeltext as pt
from PIL import Image, ImageDraw
jar, out = sys.argv[1:3]


def text(s, size=10, fill='#ffffff', outline=None):
    return pt.render(s, size=size, scale=1, fill=fill, outline=outline)


def save(rel, data):
    p = os.path.join(out, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'wb').write(data); print(rel, len(data))


# certi.pzx: buttons 49x16, image 2 = "예" (yes), 3 = "아니오" (no)
rel = 'menu/certi.pzx'
d = open(os.path.join(jar, rel), 'rb').read()
P = pzx.parse(d)
bw, bh = P['imgs'][0][:2]
num = P['imgs'][2][0] > 14             # Zenonia 1: '1.예' '2.아니오'
new = {2: text('1.Có' if num else 'Có'), 3: text('2.Không' if num else 'Không')}
save(rel, pzx.replace_images(d, new, lambda k, x, y, o, n: ((bw - n[0]) // 2, (bh - n[1]) // 2)))


def badge(rel, idx, label, y0):
    """rating badge: blank the Korean caption (rows y0..) and draw the label centred"""
    d = open(os.path.join(jar, rel), 'rb').read()
    im = pzx.decode_png(d, idx); w, h = im.size
    dr = ImageDraw.Draw(im)
    dr.rectangle((1, y0, w - 2, h - 2), fill=(0, 0, 0, 255))
    t = text(label)
    im.paste(t, ((w - t.width) // 2, y0 + (h - 1 - y0 - t.height) // 2 + 1), t)
    save(rel, pzx.replace_images(d, {idx: im}))


if os.path.exists(os.path.join(jar, 'menu/Title_1.pzx')):
    badge('menu/Title_1.pzx', 1, 'Mọi tuổi', 28)
if os.path.exists(os.path.join(jar, 'menu/ZeroGrade.pzx')):
    badge('menu/ZeroGrade.pzx', 0, 'Bạo lực', 37)
