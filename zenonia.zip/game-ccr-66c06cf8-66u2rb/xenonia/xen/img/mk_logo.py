#!/usr/bin/env python3
"""menu/logo.pzx: 555/OZ ad + Gamevil logo -> NAMP logo (full screen 240x320) for every frame.
  mk_logo.py <jar dir> <overlay dir> <logo png>"""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pzx
jar, out, png = sys.argv[1:4]
src = os.path.join(jar, 'menu', 'logo.pzx')
d = open(src, 'rb').read()
io, fo, ao = struct.unpack_from('<3I', d, 4)
_, frames = pzx.read_section(d, fo)
W, H = 240, 320
pal, rows = pzx.quantize(png, (W, H))
img = pzx.image_section(pal, [pzx.encode_image(rows, W, H)])
part = struct.pack('<HHhhB', 1, 0, -W // 2, -H // 2, 0)       # 1 part: image 0 centred
frame = pzx.pack_section(d[fo], [part] * len(frames))
bounds = sorted([io, fo, ao, len(d)])
anim = d[ao:bounds[bounds.index(ao) + 1]]
os.makedirs(os.path.join(out, 'menu'), exist_ok=True)
data = pzx.build(anim, frame, img)
open(os.path.join(out, 'menu', 'logo.pzx'), 'wb').write(data)
P = pzx.parse(data)
print('logo.pzx', len(data), 'bytes, frames', len(frames), 'colors', len(pal), [i[:3] for i in P['imgs']])
