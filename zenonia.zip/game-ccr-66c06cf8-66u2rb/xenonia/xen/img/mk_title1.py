#!/usr/bin/env python3
"""Zenonia 1 menu/Title.pzx: image 0 (title screen) Korean subtitle '제노니아 / 기억의 실타래' -> Vietnamese,
image 11 (rating badge) caption -> 'Mọi tuổi'.   mk_title1.py <jar dir> <overlay dir>"""
import sys, os
H = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, H); sys.path.insert(0, '/home/claude/work/img5/pixeltext-kit')
import pzx, pixeltext as pt, cv2, numpy as np
from PIL import Image, ImageDraw
jar, out = sys.argv[1:3]
rel = 'menu/Title.pzx'
d = open(os.path.join(jar, rel), 'rb').read()
im = pzx.decode_png(d, 0).convert('RGB')
a = np.array(im)
x0, y0, x1, y1 = 80, 256, 160, 298
reg = a[y0:y1, x0:x1].astype(int); lum = reg.mean(axis=2)
m = cv2.dilate(((lum > 185) | (lum < 60)).astype(np.uint8), np.ones((3, 3), np.uint8), iterations=2)
mask = np.zeros(a.shape[:2], np.uint8); mask[y0:y1, x0:x1] = m * 255
res = Image.fromarray(cv2.inpaint(a[:, :, ::-1].copy(), mask, 4, cv2.INPAINT_TELEA)[:, :, ::-1]).convert('RGBA')


def bold(txt, y, fill, outline):
    t = pt.render(txt, size=15, scale=1, fill=fill)
    w, h = t.size
    b = Image.new('RGBA', (w + 1, h), (0, 0, 0, 0)); b.alpha_composite(t, (0, 0)); b.alpha_composite(t, (1, 0))
    # outline 1px around the bold glyphs
    o = Image.new('RGBA', (w + 3, h + 2), (0, 0, 0, 0)); al = b.split()[3]
    sil = Image.new('RGBA', b.size, outline); sil.putalpha(al)
    for dx in (0, 1, 2):
        for dy in (0, 1, 2):
            o.alpha_composite(sil, (dx, dy))
    o.alpha_composite(b, (1, 1))
    res.alpha_composite(o, ((240 - o.width) // 2 + 4, y))


bold('Zenonia', 256, ['#ffffff', '#d8f4ff'], '#141a40')
bold('Sợi Chỉ Ký Ức', 273, ['#ffffff', '#d8f4ff'], '#141a40')
new = {0: res}
# badge
b = pzx.decode_png(d, 11); w, h = b.size
dr = ImageDraw.Draw(b); dr.rectangle((1, 36, w - 2, h - 2), fill=(0, 0, 0, 255))
t = pt.render('Mọi tuổi', size=10, scale=1, fill='#ffffff')
b.paste(t, ((w - t.width) // 2, 36 + (h - 37 - t.height) // 2 + 1), t)
new[11] = b
data = pzx.replace_images(d, new)
p = os.path.join(out, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
open(p, 'wb').write(data); print(rel, len(data))
