#!/usr/bin/env python3
"""Xenonia Việt hoá: bản dịch -> overlay cho jar.

  build_vi.py <bản dịch .tsv>... [--out build/overlay]

Bản dịch: cột 'ID', 'Tiếng Hàn', 'Tiếng Việt' (out/XEN_dich.tsv do extract.py tạo). Dòng trống = giữ tiếng Hàn.
Cột ID dạng 'ID=...' ở file sau (vd tr/override.tsv) chỉ áp cho đúng ID đó (ghi đè theo câu Hàn).
Kết quả (overlay, cấu trúc như gốc jar): data/*.zt1, script/output.dlg, binary.mod, vi/dict.txt, vi/font.bin
Mã hoá: mỗi từ (chuỗi chữ cái) = 2 byte (lead 0xC9.., trail 0xA1..) = chỉ số dòng trong dict.txt
(XenText vẽ bằng font 15px); số, dấu câu, khoảng trắng, mã điều khiển (!N !C !L !cRRGGBB %s %d) giữ ASCII.
Ô cố định (bảng Xls, chuỗi trong binary) mà câu dịch dài hơn: cả cụm chữ giữa các mã điều khiển gộp thành 1 mã.
"""
import sys, os, re, json, struct, collections, shutil
W = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, W)
import extract as X

LEAD0, TRAIL0 = 0xC9, 0xA1
MAXCODES = (0xFF - LEAD0) * 94
FONT = os.path.join(W, 'font', 'font_15px.bin')
REPL = {'…': '...', '“': '"', '”': '"', '‘': "'", '’': "'", '–': '-', '—': '-', ' ': ' ', '　': ' ',
        '·': '.', '•': '.', '×': 'x', '★': '*', '☆': '*', '♥': '*', '♡': '*', '→': '>', '←': '<'}
CTRL = re.compile(r'\[0x[0-9A-Fa-f]{6}\]|!c[0-9A-Fa-f]{6}|![NCL]|%[-0-9.]*[sdcxXu]')


def load_font_chars(path):
    data = open(path, 'rb').read()
    n = struct.unpack('>H', data[:2])[0]
    return set(data[2:2 + n].decode('utf-8'))


def is_word_char(c):
    return c.isalpha() and not ('가' <= c <= '힣') and ord(c) < 0x3000


def read_translations(paths):
    by_ko, by_id = {}, {}
    for p in paths:
        rows = [l.rstrip('\n').split('\t') for l in open(p, encoding='utf-8-sig', newline='\n')]
        head = [h.strip().lower() for h in rows[0]]
        def col(*names):
            for i, h in enumerate(head):
                for n in names:
                    if n in h: return i
            return None
        ci, ck, cv = col('id'), col('hàn', 'han'), col('việt', 'viet')
        for r in rows[1:]:
            if len(r) <= cv: continue
            vi = r[cv].replace('\\n', '\n').replace('\\t', '\t').replace('\\r', '\r')
            if vi.strip() == '': continue
            if vi.strip() == '<rỗng>': vi = ''
            i = r[ci].strip() if ci is not None else ''
            if i.startswith('ID='): by_id[i[3:]] = vi
            elif ck is not None and len(r) > ck: by_ko[r[ck].replace('\\n', '\n').replace('\\t', '\t').replace('\\r', '\r')] = vi
    return by_ko, by_id


class Encoder:
    def __init__(self, font_chars):
        self.fc = font_chars
        self.dict = []
        self.index = {}
        self.missing = collections.Counter()

    def clean(self, s):
        return ''.join(REPL.get(c, c) for c in s)

    def code(self, w):
        k = self.index.get(w)
        if k is None:
            if len(self.dict) >= MAXCODES: raise SystemExit('dict.txt đầy (%d mã)' % MAXCODES)
            k = len(self.dict); self.dict.append(w); self.index[w] = k
        return bytes([LEAD0 + k // 94, TRAIL0 + k % 94])

    def fontsafe(self, w):
        for ch in w:
            if ch not in self.fc: self.missing[ch] += 1
        return ''.join(ch if ch in self.fc else '?' for ch in w)

    def ascii(self, c):
        if ord(c) < 0x80: return bytes([ord(c)])
        try: return c.encode('euc-kr')          # Hangul / symbols left in the translation
        except UnicodeEncodeError: self.missing[c] += 1; return b'?'

    def encode(self, s):
        """words -> codes, everything else 1 byte ASCII"""
        s = self.clean(s)
        out = bytearray(); i = 0
        while i < len(s):
            m = CTRL.match(s, i)
            if m:
                out += m.group().encode('ascii'); i = m.end(); continue
            c = s[i]
            if is_word_char(c):
                j = i
                while j < len(s) and is_word_char(s[j]): j += 1
                out += self.code(self.fontsafe(s[i:j])); i = j; continue
            out += self.ascii(c); i += 1
        return bytes(out)

    def encode_compact(self, s):
        """each run of text between control codes -> one code (fits any slot >= 2 bytes per run)"""
        s = self.clean(s)
        out = bytearray(); pos = 0
        for m in list(CTRL.finditer(s)) + [None]:
            seg = s[pos:m.start()] if m else s[pos:]
            if seg.strip():
                core = seg.strip(' \t')
                a = seg.index(core)
                out += seg[:a].encode('ascii')
                out += self.code(self.fontsafe(core))
                out += seg[a + len(core):].encode('ascii')
            else:
                out += seg.encode('ascii', 'replace')
            if m is None: break
            out += m.group().encode('ascii'); pos = m.end()
        return bytes(out)

    def fit(self, s, limit):
        b = self.encode(s)
        if limit is None or len(b) <= limit: return b, False
        b = self.encode_compact(s)
        return b, True


def check_codes(ko, vi):
    a = sorted(re.findall(r'%[-0-9.]*[sdcxXu]', ko)); b = sorted(re.findall(r'%[-0-9.]*[sdcxXu]', vi))
    issues = []
    if re.findall(r'%[-0-9.]*[sdcxXu]', ko) != re.findall(r'%[-0-9.]*[sdcxXu]', vi):
        issues.append('thứ tự/số %s %d khác bản gốc')
    if ko.count('!N') and not vi.count('!N') and len(ko.split('!N')) > 2:
        pass
    return issues


def main():
    args = sys.argv[1:]
    out = os.path.join(W, 'build', 'overlay')
    if '--out' in args:
        i = args.index('--out'); out = args[i + 1]; del args[i:i + 2]
    by_ko, by_id = read_translations(args)
    cat = json.load(open(os.path.join(W, 'catalog.json'), encoding='utf-8'))
    enc = Encoder(load_font_chars(FONT))
    report = []
    stats = collections.Counter()

    def tr(e):
        vi = by_id.get(e['id'], by_ko.get(e['ko']))
        if vi is None: stats['chưa dịch'] += 1; return None
        stats['đã dịch'] += 1
        for p in check_codes(e['ko'], vi): report.append('%s: %s | %s' % (e['id'], p, vi))
        return vi

    def put(e, limit):
        vi = tr(e)
        if vi is None: return None
        b, compact = enc.fit(vi, limit)
        if compact: stats['gộp cụm'] += 1
        if limit is not None and len(b) > limit:
            report.append('%s: QUÁ DÀI (%d > %d byte) | %s' % (e['id'], len(b), limit, vi)); return None
        return b

    if os.path.exists(out): shutil.rmtree(out)
    os.makedirs(os.path.join(out, 'data')); os.makedirs(os.path.join(out, 'script')); os.makedirs(os.path.join(out, 'vi'))
    byfile = collections.defaultdict(list)
    for e in cat: byfile[e['id'].split(':')[0] + ':' + (e['id'].split(':')[1] if e['id'][0] in 'SXG' else '')].append(e)

    # zt1 string tables
    for key, es in byfile.items():
        kind, name = key.split(':')
        if kind not in ('S', 'X'): continue
        path = os.path.join(X.JAR, 'data', name)
        u = X.zt1_load(path)
        changed = False
        if kind == 'S':
            strs = X.parse_gst(u)
            for e in es:
                b = put(e, None)
                if b is not None: strs[int(e['id'].split(':')[2])] = b; changed = True
            nu = X.build_gst(strs)
        else:
            types, table = X.parse_gxl(u)
            for e in es:
                _, _, r, c = e['id'].split(':'); r = int(r); c = int(c)
                b = put(e, types[c] - 10 - 1)
                if b is not None:
                    table[r][c] = b + b'\0' * (types[c] - 10 - len(b)); changed = True
            nu = X.build_gxl(types, table)
        if changed: X.zt1_save(os.path.join(out, 'data', name), nu)

    # dialogue
    dlg = X.parse_dlg(open(os.path.join(X.JAR, 'script', 'output.dlg'), 'rb').read())
    for e in byfile['D:']:
        b = put(e, None)
        if b is not None: dlg[int(e['id'][2:])] = b
    open(os.path.join(out, 'script', 'output.dlg'), 'wb').write(X.build_dlg(dlg))

    # *.gui layouts: in place, u8 length (incl. NUL) kept, shorter text padded with NUL
    guis = {}
    for e in [e for k, es in byfile.items() if k.startswith('G:') for e in es]:
        b = put(e, e['max'])
        if b is None: continue
        _, rel, a = e['id'].split(':'); a = int(a, 16)
        if rel not in guis: guis[rel] = bytearray(open(os.path.join(X.JAR, rel), 'rb').read())
        g = guis[rel]
        assert g[a - 1] == e['max'] + 1
        g[a:a + e['max']] = b + b'\0' * (e['max'] - len(b))
    for rel, g in guis.items():
        os.makedirs(os.path.dirname(os.path.join(out, rel)), exist_ok=True)
        open(os.path.join(out, rel), 'wb').write(g)

    # binary.mod: in place, slot = bytes to the next string
    sys.path.insert(0, os.path.join(W, '..', 'tools'))
    os.environ['ELF'] = os.path.join(X.JAR, 'binary.mod')
    import img
    binm = bytearray(img.d)
    # 32-bit words of the binary: a word pointing INSIDE a string means the compiler shares that
    # string's tail (e.g. "%d" = last bytes of "...: %d"); the tail must stay at the same address
    words = set()
    for sa, ssize, so, styp in img.SECS:
        if styp == 8: continue
        for k in range(0, ssize - 3, 4): words.add(struct.unpack_from('<I', img.d, so + k)[0])
    for e in byfile['B:']:
        b = put(e, e['max'])
        if b is None: continue
        a = int(e['id'][2:], 16)
        o = img.off(a)
        orig = img.d[o:o + img.d.index(b'\0', o) - o]
        for k in range(2, len(orig)):          # offset 1 = after a leading tab, kept by the translations
            if a + k not in words: continue
            suf = orig[k:]
            if b.endswith(suf) and len(b) - len(suf) <= k:
                b = b[:len(b) - len(suf)] + b' ' * (k - (len(b) - len(suf))) + suf
            else:
                report.append('%s: ĐUÔI CHUỖI DÙNG CHUNG ở +%d (%r) không giữ được -> giữ bản gốc' % (e['id'], k, suf)); b = None; break
        if b is None: continue
        if b[:1] != orig[:1] and orig[:1] == b'\t': report.append('%s: thiếu tab đầu' % e['id'])
        binm[o:o + e['max'] + 1] = b + b'\0' * (e['max'] + 1 - len(b))
    # code patches: patches.txt lines 'addr old_hex new_hex  # comment'
    pp = os.path.join(W, 'patches.txt')
    if os.path.exists(pp):
        for l in open(pp, encoding='utf-8'):
            l = l.split('#')[0].split()
            if not l: continue
            a, old, new = int(l[0], 16), bytes.fromhex(l[1]), bytes.fromhex(l[2])
            o = img.off(a)
            if binm[o:o + len(old)] != old: raise SystemExit('patch %x: không khớp mã gốc (%s)' % (a, binm[o:o + len(old)].hex()))
            binm[o:o + len(new)] = new
            stats['vá mã'] += 1
    open(os.path.join(out, 'binary.mod'), 'wb').write(binm)

    with open(os.path.join(out, 'vi', 'dict.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(enc.dict) + '\n')
    shutil.copy(FONT, os.path.join(out, 'vi', 'font.bin'))
    rep = os.path.join(W, 'build', 'bao-cao-build.txt')
    with open(rep, 'w', encoding='utf-8') as f:
        f.write('Thống kê: %s\nMã từ điển: %d / %d\n' % (dict(stats), len(enc.dict), MAXCODES))
        if enc.missing: f.write('Ký tự font thiếu: %s\n' % dict(enc.missing))
        f.write('\n'.join(report) + '\n')
    print('overlay:', out, dict(stats), 'dict', len(enc.dict), 'cảnh báo', len(report))
    if enc.missing: print('font thiếu:', dict(enc.missing))


if __name__ == '__main__':
    main()
