#!/usr/bin/env python3
"""Xenonia Việt hoá: trích toàn bộ text tiếng Hàn -> catalog.json + out/XEN_dich.tsv

Nguồn (thư mục xen/jar = jar gốc đã bung):
  data/Str*.zt1   GST: 'GST\\x01' u16 n, u16 off[n+1] (tuyệt đối, off[n] = cuối), chuỗi kết thúc NUL
  data/Xls*.zt1   GXL: 'GXL\\x01' u16 rowSize, u16 cols, u16 rows, u8 type[cols], rows*rowSize
                  type 0/1 = 1 byte, 2/3 = 2 byte, 4 = 4 byte, >10 = chuỗi (type-10) byte
  zt1 = u32 kích thước file, u32 kích thước giải nén, zlib
  script/output.dlg  u32 n, u32 off[n], chuỗi NUL
  binary.mod      chuỗi EUC-KR trong .text (>= 0x5d000) và .data; ô = tới đầu chuỗi kế tiếp
"""
import os, re, struct, zlib, json, glob, sys, collections
W = os.path.dirname(os.path.abspath(__file__))
JAR = os.path.join(W, '..', 'jar')
HAN = re.compile(rb'[\xb0-\xc8][\xa1-\xfe]')


def has_han(b):
    return HAN.search(b) is not None


def dec(b):
    return b.decode('euc-kr', 'replace')


def zt1_load(path):
    d = open(path, 'rb').read()
    return zlib.decompress(d[8:])


def zt1_save(path, u):
    c = zlib.compress(u, 9)
    open(path, 'wb').write(struct.pack('<II', len(c) + 8, len(u)) + c)


def parse_gst(u):
    assert u[:4] == b'GST\x01'
    n = struct.unpack_from('<H', u, 4)[0]
    offs = struct.unpack_from('<%dH' % (n + 1), u, 6)
    out = []
    for i in range(n):
        s = u[offs[i]:offs[i + 1]]
        e = s.find(b'\0')
        out.append(s[:e] if e >= 0 else s)
    return out


def build_gst(strs):
    n = len(strs)
    pos = 6 + 2 * (n + 1)
    offs, body = [], bytearray()
    for s in strs:
        offs.append(pos + len(body)); body += s + b'\0'
    offs.append(pos + len(body))
    if offs[-1] > 0xFFFF: raise ValueError('GST quá 64 KB')
    return b'GST\x01' + struct.pack('<H', n) + struct.pack('<%dH' % (n + 1), *offs) + bytes(body)


def col_width(t):
    if t <= 1: return 1
    if t <= 3: return 2
    if t == 4: return 4
    if t > 10: return t - 10
    raise ValueError('kiểu cột lạ %d' % t)


def parse_gxl(u):
    assert u[:4] == b'GXL\x01'
    rs, cols, rows = struct.unpack_from('<HHH', u, 4)
    types = list(u[10:10 + cols])
    widths = [col_width(t) for t in types]
    assert sum(widths) == rs and len(u) == 10 + cols + rs * rows, 'GXL lệch kích thước'
    data = 10 + cols
    table = []
    for r in range(rows):
        row, o = [], data + r * rs
        for c in range(cols):
            row.append(u[o:o + widths[c]]); o += widths[c]
        table.append(row)
    return types, table


def build_gxl(types, table):
    widths = [col_width(t) for t in types]
    rs = sum(widths)
    out = bytearray(b'GXL\x01' + struct.pack('<HHH', rs, len(types), len(table)) + bytes(types))
    for row in table:
        for c, cell in enumerate(row):
            assert len(cell) == widths[c]
            out += cell
    return bytes(out)


def parse_dlg(d):
    n = struct.unpack_from('<I', d, 0)[0]
    offs = struct.unpack_from('<%dI' % n, d, 4)
    out = []
    for i in range(n):
        e = d.index(b'\0', offs[i])
        out.append(d[offs[i]:e])
    return out


def build_dlg(strs):
    n = len(strs)
    pos = 4 + 4 * n
    offs, body = [], bytearray()
    for s in strs:
        offs.append(pos + len(body)); body += s + b'\0'
    return struct.pack('<I', n) + struct.pack('<%dI' % n, *offs) + bytes(body)


def bin_strings(path):
    """[(addr, slot_bytes, bytes, nrefs)] Hangul strings of binary.mod"""
    sys.path.insert(0, os.path.join(W, '..', 'tools'))
    os.environ['ELF'] = path
    import img
    res = []
    for addr, size, o, typ in img.SECS:
        if typ == 8: continue
        blob = img.d[o:o + size]
        cands = [(addr + m.start(), m.group()[:-1]) for m in re.finditer(rb'[\x09\x0a\x20-\x7e\xa1-\xfe]{2,}\x00', blob)]
        for k, (a, s) in enumerate(cands):
            if a < 0x5d000 or not has_han(s): continue
            try: s.decode('euc-kr')
            except UnicodeDecodeError: continue
            # slot: bytes up to the next non-NUL byte (strings are padded to 4 / array stride)
            e = a - addr + len(s)
            while e < len(blob) and blob[e] == 0: e += 1
            # never beyond the next 4-byte boundary after the NUL (the zeros after may be data)
            end = min(addr + e, (a + len(s) + 1 + 3) & ~3)
            res.append((a, end - a, s, len(img.xrefs(a))))
    return res


def gui_strings():
    """[(relpath, offset, bytes, max)] Hangul strings of *.gui (u8 len incl. NUL, then the string)"""
    res = []
    for root, ds, fs in os.walk(JAR):
        for f in sorted(fs):
            if not f.endswith('.gui'): continue
            p = os.path.join(root, f); rel = os.path.relpath(p, JAR)
            d = open(p, 'rb').read()
            for m in re.finditer(rb'[\x20-\x7e\xa1-\xfe]+\x00', d):
                a = m.start(); s = m.group()[:-1]
                if a < 1 or d[a - 1] != len(s) + 1 or not has_han(s): continue
                try: s.decode('euc-kr')
                except UnicodeDecodeError: continue
                res.append((rel, a, s, len(s)))
    return res


def main():
    cat = []   # {id, src, ko, max}
    for f in sorted(glob.glob(os.path.join(JAR, 'data', '*.zt1'))):
        name = os.path.basename(f)
        u = zt1_load(f)
        if u[:3] == b'GST':
            for i, s in enumerate(parse_gst(u)):
                if has_han(s): cat.append({'id': 'S:%s:%d' % (name, i), 'ko': dec(s)})
        else:
            types, table = parse_gxl(u)
            for r, row in enumerate(table):
                for c, cell in enumerate(row):
                    if types[c] > 10:
                        s = cell.split(b'\0')[0]
                        if has_han(s): cat.append({'id': 'X:%s:%d:%d' % (name, r, c), 'ko': dec(s), 'max': types[c] - 10})
    for i, s in enumerate(parse_dlg(open(os.path.join(JAR, 'script', 'output.dlg'), 'rb').read())):
        if has_han(s): cat.append({'id': 'D:%d' % i, 'ko': dec(s)})
    for rel, a, s, mx in gui_strings():
        cat.append({'id': 'G:%s:%x' % (rel, a), 'ko': dec(s), 'max': mx})
    for a, slot, s, nref in bin_strings(os.path.join(JAR, 'binary.mod')):
        cat.append({'id': 'B:%x' % a, 'ko': dec(s), 'max': slot - 1, 'refs': nref})
    json.dump(cat, open(os.path.join(W, 'catalog.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    # unique Korean strings, first occurrence keeps the ID
    os.makedirs(os.path.join(W, 'out'), exist_ok=True)
    seen = collections.OrderedDict()
    for e in cat:
        k = e['ko']
        if k not in seen: seen[k] = (e['id'], 1, e.get('max'))
        else:
            i, n, m = seen[k]
            mx = e.get('max')
            seen[k] = (i, n + 1, m if mx is None else (mx if m is None else min(m, mx)))
    with open(os.path.join(W, 'out', 'XEN_dich.tsv'), 'w', encoding='utf-8') as f:
        f.write('ID\tTiếng Hàn\tTiếng Việt\tSố lần\tTối đa byte\n')
        for k, (i, n, m) in seen.items():
            f.write('%s\t%s\t\t%d\t%s\n' % (i, k.replace('\n', '\\n'), n, '' if m is None else m))
    chars = sum(len(k) for k in seen)
    print('catalog: %d mục, %d chuỗi không trùng, %d ký tự' % (len(cat), len(seen), chars))
    c = collections.Counter(e['id'].split(':')[0] + ':' + (e['id'].split(':')[1] if e['id'][0] in 'SXG' else '') for e in cat)
    for k, v in sorted(c.items()): print('  ', k, v)


if __name__ == '__main__':
    main()
