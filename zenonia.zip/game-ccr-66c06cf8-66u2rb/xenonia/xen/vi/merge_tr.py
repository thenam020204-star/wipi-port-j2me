#!/usr/bin/env python3
"""tr/vi_*.txt (dòng 'ID<TAB>tiếng Việt') -> out/XEN_viet.tsv (ID, Tiếng Hàn, Tiếng Việt) cho build_vi.py.
File tên *_id.txt: chỉ áp cho đúng ID đó (không lan sang câu Hàn trùng)."""
import os, json, glob
W = os.path.dirname(os.path.abspath(__file__))
cat = {e['id']: e for e in json.load(open(os.path.join(W, 'catalog.json'), encoding='utf-8'))}
rows, n, bad = [], 0, []
for p in sorted(glob.glob(os.path.join(W, 'tr', 'vi_*.txt'))):
    only_id = p.endswith('_id.txt')
    for l in open(p, encoding='utf-8', newline='\n'):
        l = l.rstrip('\n')
        if not l.strip() or l.startswith('#'): continue
        i, _, vi = l.partition('\t')
        if i not in cat: bad.append((os.path.basename(p), i)); continue
        rows.append(('ID=' + i if only_id else i, cat[i]['ko'].replace('\n', '\\n').replace('\t', '\\t').replace('\r', '\\r'), vi.replace('\t', '\\t'))); n += 1
os.makedirs(os.path.join(W, 'out'), exist_ok=True)
with open(os.path.join(W, 'out', 'XEN_viet.tsv'), 'w', encoding='utf-8', newline='\n') as f:
    f.write('ID\tTiếng Hàn\tTiếng Việt\n')
    # by-ID rows last so they win
    for r in sorted(rows, key=lambda r: r[0].startswith('ID=')): f.write('\t'.join(r) + '\n')
print('gộp', n, 'dòng', ('LỖI ID: %s' % bad) if bad else '')
