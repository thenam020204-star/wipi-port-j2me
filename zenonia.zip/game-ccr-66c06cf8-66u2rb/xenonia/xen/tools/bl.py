# bl.py <hex target>... : Thumb BL call sites
import sys, struct, os
sys.path.insert(0, os.path.dirname(__file__)); import img
a0, blob = img.text_bytes()
def callers(target):
    res = []
    for o in range(0, len(blob) - 4, 2):
        h1, h2 = struct.unpack_from('<HH', blob, o)
        if (h1 & 0xF800) == 0xF000 and (h2 & 0xF800) in (0xF800, 0xE800):
            off = ((h1 & 0x7FF) << 12) | ((h2 & 0x7FF) << 1)
            if off & 0x400000: off -= 0x800000
            if a0 + o + 4 + off == target: res.append(a0 + o)
    return res
if __name__ == '__main__':
    for t in sys.argv[1:]:
        t = int(t, 16); c = callers(t)
        print(hex(t), [(hex(x), hex(img.funcstart(x) or 0)) for x in c])
def vcallers(target):
    """calls through the r3 veneer: ldr r3,=target|1 ; bl veneer"""
    res = []
    for x in img.xrefs(target | 1):
        res += img.literal_users(x)
    return res
