#!/bin/bash
# Build Zenonia (LGT WIPI, Gamevil) -> J2ME jar.
#   ./make_xen.sh [suffix]          Zenonia 1 (XEN.zip, xen/)   -> dist_xen/XEN_LGT<suffix>.jar
#   GAME=2 ./make_xen.sh [suffix]   Zenonia 2 (XEN2.zip, xen2/) -> dist_xen/XEN2_LGT<suffix>.jar
#   VI=1 kèm overlay Việt hoá <dir>/vi/build/overlay ; AOT từ xenj/aot/xen<N>/ nếu có
set -e
W=/home/claude/work; cd $W
export JAVA_TOOL_OPTIONS=
if [ "$GAME" = 2 ]; then D=xen2; Z=XEN2.zip; export GNAME="Zenonia 2" GBASE=XEN2_LGT AOTDIR=$W/xenj/aot/xen2
else D=xen; Z=XEN.zip; export GNAME="Zenonia" GBASE=XEN_LGT AOTDIR=$W/xenj/aot/xen1; fi
(cd xenj && AOTDIR= ./tbuild.sh build/t 2>&1 | grep -v JAVA_TOOL || true)
rm -rf $D/overlay && mkdir -p $D/overlay/sound
java -cp xenj/build/t SndConvert5 $D/jar/sound $D/overlay/sound /sound/
[ -d $D/img/overlay ] && cp -r $D/img/overlay/. $D/overlay/
[ -n "$VI" ] && cp -r $D/vi/build/overlay/. $D/overlay/
# logo Gamevil -> NAMP
[ -n "$VI" ] && python3 xen/img/mk_logo.py $D/jar $D/overlay xen/img/logo_namp.png
# chữ Hàn trong ảnh (nút Có/Không, nhãn độ tuổi)
[ -n "$VI" ] && python3 xen/img/mk_images.py $D/jar $D/overlay
[ -n "$VI" ] && [ "$GAME" != 2 ] && python3 xen/img/mk_title1.py $D/jar $D/overlay
(cd xenj && OVERLAY=$W/$D/overlay SUFFIX=$1 ./build.sh $W/$Z $W/dist_xen)
ls -l dist_xen | tail -3
