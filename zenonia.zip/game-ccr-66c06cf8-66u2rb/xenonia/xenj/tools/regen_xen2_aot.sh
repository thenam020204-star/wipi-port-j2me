#!/bin/bash
# Regenerate aot/xen2/hl4/aot/LgtAot.java (Zenonia 2) from profiles/xen2_*.txt.
# BIN: binary.mod đã vá (overlay của GAME=2 VI=1 make_xen.sh), mặc định ../xen2/overlay/binary.mod.
# Excludes: XenText patched sites 0xe218 (draw) and 0xe50e (measure).
cd "$(dirname "$0")/.."
python3 tools/aotgen.py --bin ${BIN:-../xen2/overlay/binary.mod} --fileoff 0x34 --size 0x8b538 --base 0x1000 --class LgtAot \
  --out aot/xen2/hl4/aot/LgtAot.java --maxinsns 1000 --coldcut 0.001 --funcregions --hostcalls --funcmaxinsns 700 --maxbytes 7200 --funcmin ${FUNCMIN:-20000} --maxregions 4000 \
  --exclude e218-e21c --exclude e50e-e512 $EXTRA profiles/xen2_*.txt
