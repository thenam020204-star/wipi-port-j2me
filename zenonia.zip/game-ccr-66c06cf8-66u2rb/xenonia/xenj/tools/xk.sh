#!/bin/bash
# xk.sh name total_ms every_ms "post-title keys" [storage_src]  -- tới menu chính rồi đi tiếp
PRE="2000:OK;2500:OK;2500:OK;2500:OK;2500:OK;2500:OK;5000"
exec /home/claude/work/xenj/tools/run.sh "$1" "$2" "$3" "seq:$PRE;$4" "$5" "$6" "$7"
