#!/bin/bash
# xk2.sh name total every "keys after title" -- Zenonia 2
PRE="2000:OK;2500:OK;2500:OK;2500:OK;2500:OK;2500:OK;5000"
GAMEZIP=XEN2.zip exec /home/claude/work/xenj/tools/run.sh "$1" "$2" "$3" "seq:$PRE;$4" "$5" "$6" "$7"
