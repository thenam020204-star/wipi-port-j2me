#!/bin/bash
# Regenerate src/aot/hl4/aot/LgtAot.java (Xenonia) from profiles/xen_*.txt (absolute addresses).
# BIN: binary.mod đã vá (overlay của make_xen.sh VI=1), mặc định ../xen/overlay/binary.mod.
# Excludes: XenText patched sites 0x53578 (draw) and 0x53866 (measure).
cd "$(dirname "$0")/.."
python3 tools/aotgen.py --bin ${BIN:-../xen/overlay/binary.mod} --fileoff 0x34 --size 0x651bc --base 0x1000 --class LgtAot \
  --out aot/xen1/hl4/aot/LgtAot.java --maxinsns 1000 --coldcut 0.001 --funcregions --hostcalls --funcmaxinsns 700 --maxbytes 7200 --funcmin ${FUNCMIN:-20000} --maxregions 4000 \
  --exclude 53578-5357c --exclude 53866-5386a $EXTRA profiles/xen_*.txt
