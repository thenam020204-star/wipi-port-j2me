package hl4.lgt;

import hl4.core.VnFont;
import hl4.cpu.Cpu;
import hl4.cpu.Memory;

/**
 * Xenonia Vietnamese text. Vietnamese words are stored in the game data as 2-byte codes (lead 0xC9..,
 * trail 0xA1.., index into dict.txt), so every "byte >= 0x80 = 2-byte character" rule of the game keeps
 * working and a word is one unbreakable glyph for the game's own wrapping.
 * <p>
 * The game's text module (font object: +0x24 ASCII bitmaps, +0x48 colour, +0x54/0x55 Hangul w/h,
 * +0x56/0x57 ASCII w/h, +0x5a letter spacing, +0x5b/0x5c line spacing/height) has two loops that
 * handle a 2-byte character; both start with "ldr r2, [sp, #0x24]; cmp r2, #0" (the KS->johab flag),
 * which is replaced by a call to an HLE stub:
 * <ul>
 * <li>draw 0x5345c, site 0x53578: a word is wrapped like a Hangul glyph, rendered with the VnFont
 * into a 1 bpp bitmap and blitted with the game's own glyph blit 0x52e50 (clip, colour, y offset
 * stay the game's), then the loop continues at 0x5376a;</li>
 * <li>measure 0x53790, site 0x53866: r2 = word width + letter spacing, continue at 0x53892.</li>
 * </ul>
 */
final class XenText {
    static final int LEAD0 = 0xC9, TRAIL0 = 0xA1;
    static final int HLE_DRAW = 110, HLE_MEASURE = 111;

    /**
     * Per-game addresses (same Gamevil text module, different layout):
     * {stub, draw site, draw flag==0, draw flag!=0, draw loop tail, measure site, measure flag==0,
     *  measure flag!=0, measure continue (after width sum), glyph blit}
     */
    static final int[][] GAMES = {
        {0x67000, 0x53578, 0x53588, 0x5357e, 0x5376a, 0x53866, 0x53876, 0x5386c, 0x53892, 0x52e50}, // Zenonia
        {0x8d000, 0xe218, 0xe228, 0xe21e, 0xe40a, 0xe50e, 0xe51e, 0xe514, 0xe53a, 0xdae8},          // Zenonia 2
    };
    private int[] g;
    private int STUB_DRAW, STUB_MEASURE, DRAW_SITE, MEASURE_SITE, BLIT;

    private final LgtRuntime rt;
    private final Cpu cpu;
    private final Memory mem;
    private final VnFont font;
    private final String[] dict;
    private final int[] width;
    private final int spaceW;
    public int yOff;
    private int buf;
    private static final int BUF_SIZE = 4096;

    XenText(LgtRuntime rt, VnFont font, String[] dict) {
        this.rt = rt;
        this.cpu = rt.cpu;
        this.mem = rt.mem;
        this.font = font;
        this.dict = dict;
        int sw = font.advance(' ');
        spaceW = sw > 0 ? sw : 4;
        width = new int[dict.length];
        for (int i = 0; i < dict.length; i++) width[i] = measure(dict[i]);
        // Hangul glyphs are 11 rows with the baseline near row 9; put the VnFont baseline there
        yOff = 9 - font.baseline();
    }

    private int adv(char c) {
        if (c == ' ') return spaceW;
        int a = font.advance(c);
        return a > 0 ? a : 0;
    }

    private int measure(String s) {
        int w = 0;
        for (int i = 0; i < s.length(); i++) w += adv(s.charAt(i));
        return w;
    }

    void install() {
        for (int i = 0; i < GAMES.length && g == null; i++) {
            int[] c = GAMES[i];
            if (sig(c[1]) && sig(c[5])) g = c;
        }
        if (g == null) throw new RuntimeException("Xenonia text: unknown binary (text module not found)");
        STUB_DRAW = g[0];
        STUB_MEASURE = g[0] + 8;
        DRAW_SITE = g[1];
        MEASURE_SITE = g[5];
        BLIT = g[9];
        check(DRAW_SITE);
        check(MEASURE_SITE);
        cpu.makeStub(STUB_DRAW, (LgtRuntime.CAT_HLE << 16) | HLE_DRAW);
        cpu.makeStub(STUB_MEASURE, (LgtRuntime.CAT_HLE << 16) | HLE_MEASURE);
        rt.patchBL(DRAW_SITE, STUB_DRAW);
        rt.patchBL(MEASURE_SITE, STUB_MEASURE);
    }

    private boolean sig(int s) {
        return mem.isMapped(s) && mem.read16(s) == 0x9a09 && mem.read16(s + 2) == 0x2a00;
    }

    private void check(int s) {
        // ldr r2, [sp, #0x24] ; cmp r2, #0
        if (mem.read16(s) != 0x9a09 || mem.read16(s + 2) != 0x2a00)
            throw new RuntimeException("Xenonia text: unexpected code at " + Integer.toHexString(s));
    }

    /** dict index of the 2-byte code (lead << 8 | trail), or -1 */
    private int index(int code) {
        int c = (code >> 8) & 0xFF, c2 = code & 0xFF;
        if (c < LEAD0 || c2 < TRAIL0 || c2 == 0xFF) return -1;
        int k = (c - LEAD0) * 94 + (c2 - TRAIL0);
        return k < dict.length ? k : -1;
    }

    /** Pixel width of the word with this code (for other HLE users), or -1. */
    int wordWidth(int code) {
        int k = index(code);
        return k < 0 ? -1 : width[k];
    }

    /** HLE: draw loop site 0x53578. r4 = 2-byte code, r5 = font, r6 = x, sp = frame of 0x5345c. */
    void draw() {
        int sp = cpu.r[13];
        int k = index(cpu.r[4]);
        if (k < 0) {
            int f = mem.read32(sp + 0x24);
            cpu.r[2] = f;
            cpu.r[14] = (f == 0 ? g[2] : g[3]) | 1;
            return;
        }
        int fo = cpu.r[5];
        int w = width[k];
        int x = cpu.r[6];
        int maxW = mem.read32(sp + 0x48);
        if (maxW > 0 && x + w > maxW) { // wrap like a Hangul glyph
            x = mem.read32(sp + 0x20);
            mem.write32(sp + 0x44, mem.read32(sp + 0x44) + mem.read8(fo + 0x5c) + mem.read8(fo + 0x5b));
        }
        int y = mem.read32(sp + 0x44);
        if (w > 0) blit(fo, x, y + yOff, dict[k], w);
        cpu.r[6] = x + w + mem.read8(fo + 0x5a);
        cpu.r[14] = g[4] | 1;
    }

    /** HLE: measure loop site 0x53866. r4 = 2-byte code, r7 = font. */
    void measure() {
        int sp = cpu.r[13];
        int k = index(cpu.r[4]);
        if (k < 0) {
            int f = mem.read32(sp + 0x24);
            cpu.r[2] = f;
            cpu.r[14] = (f == 0 ? g[6] : g[7]) | 1;
            return;
        }
        cpu.r[2] = width[k] + mem.read8(cpu.r[7] + 0x5a);
        cpu.r[14] = g[8] | 1;
    }

    private void blit(int fo, int x, int y, String s, int w) {
        int h = font.height;
        int nbytes = (w * h + 7) >> 3;
        if (nbytes > BUF_SIZE) return;
        if (buf == 0) buf = rt.alloc(BUF_SIZE);
        byte[] bits = new byte[nbytes];
        int cx = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int[] px = c == ' ' ? null : font.pixels(c);
            if (px != null) {
                for (int j = 0; j < px.length; j++) {
                    int gx = cx + (px[j] & 0xFF), gy = px[j] >> 8;
                    if (gx >= w || gy >= h) continue;
                    int bit = gy * w + gx;
                    bits[bit >> 3] |= (byte) (0x80 >> (bit & 7));
                }
            }
            cx += adv(c);
        }
        mem.writeBytes(buf, bits, 0, nbytes);
        cpu.call(BLIT | 1, new int[]{fo, x, y, w, h, buf});
    }
}
