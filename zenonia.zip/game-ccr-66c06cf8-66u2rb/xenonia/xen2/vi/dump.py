import json,sys
cat=json.load(open('catalog.json'))
kos=set(l.split('\t')[1].replace('\\n','\n').replace('\\t','\t').replace('\\r','\r') for l in open('out/XEN_viet.tsv',encoding='utf-8',newline='\n'))
pre=sys.argv[1]; seen=set()
for e in cat:
    if e['id'].startswith(pre) and e['ko'] not in kos and e['ko'] not in seen:
        seen.add(e['ko']); print('%s\t%s' % (e['id'], e['ko'].replace('\n','\\n')))
